#!/usr/bin/env python3
"""Offline tests for otsense-prep.py (no root, no network, no NetworkManager needed). Run:  python3 tests/test_prep.py"""
import importlib.util, json, os, shutil, struct, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PREP = os.path.join(HERE, "..", "overlay", "opt", "otsense", "otsense-prep.py")


def mk(tmp, nics):
    sysd = os.path.join(tmp, "sys")
    for n, kind, car in nics:
        b = os.path.join(sysd, n)
        os.makedirs(os.path.join(b, "device"))
        open(os.path.join(b, "address"), "w").write("aa:bb:cc:00:00:%02x\n" % (len(n) * 3))
        open(os.path.join(b, "type"), "w").write("1\n")
        open(os.path.join(b, "carrier"), "w").write("%d\n" % car)
        if kind == "wifi":
            os.makedirs(os.path.join(b, "wireless"))
    # things that must be ignored
    for n in ("lo", "docker0", "veth123"):
        os.makedirs(os.path.join(sysd, n))
    return sysd


def stamp(path, d):
    j = json.dumps(d).encode()
    open(path, "wb").write(b"OTSENSE_SLOT_V1\n" + struct.pack(">I", len(j)) + j + bytes(65536 - 20 - len(j)))


def run(tmp, sysd, slot=None, ports=None, pre=None):
    st, rn, nm = [os.path.join(tmp, x) for x in ("state", "run", "nm")]
    sf = os.path.join(tmp, "otsense-slot.bin")
    if slot is not None:
        stamp(sf, slot)
    if ports is not None:
        os.makedirs(st, exist_ok=True)
        json.dump(ports, open(os.path.join(st, "ports.json"), "w"))
    e = dict(os.environ, OTS_DRY="1", OTS_SYS=sysd, OTS_STATE=st, OTS_RUN=rn, OTS_NM=nm, OTS_SLOTFILES=sf)
    r = subprocess.run([sys.executable, PREP], env=e, capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    env = {}
    for ln in open(os.path.join(rn, "env")):
        k, v = ln.rstrip("\n").split("=", 1)
        env[k] = v.strip("'")
    return env, nm, st, sf


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        check.bad += 1
check.bad = 0

BASE = {"site": "Plant 1", "central": "https://c.example.com", "token": "tok123", "mode": "dhcp", "console_password": "pw-pw-pw-1"}

# 1. Raspberry Pi with stamped Wi-Fi: wlan0 = management, eth0 = SPAN
with tempfile.TemporaryDirectory() as t:
    s = mk(t, [("eth0", "eth", 1), ("wlan0", "wifi", 1)])
    env, nm, st, sf = run(t, s, dict(BASE, wifi_ssid="Plant WiFi", wifi_psk="secret-pass-1", wifi_country="IN", mgmt="wifi"))
    check("Pi: management = wlan0", env["MGMT"] == "wlan0")
    check("Pi: SPAN = eth0", env["CAP"] == "eth0")
    kf = open(os.path.join(nm, "system-connections", "otsense-wifi.nmconnection")).read()
    check("Pi: Wi-Fi keyfile has ssid + psk", "ssid=Plant WiFi" in kf and "psk=secret-pass-1" in kf and "interface-name=wlan0" in kf)
    check("Pi: keyfile is 0600", oct(os.stat(os.path.join(nm, "system-connections", "otsense-wifi.nmconnection")).st_mode & 0o777) == "0o600")
    conf = open(os.path.join(nm, "conf.d", "90-otsense-ports.conf")).read()
    check("Pi: eth0 unmanaged, no auto-default", "interface-name:eth0" in conf and "no-auto-default=*" in conf)
    check("Pi: configured", env["CONFIGURED"] == "1" and env["TOKEN"] == "tok123")

# 2. VM with 4 NICs, no Wi-Fi: first = management, other three = SPAN (natural sort: eth10 after eth2)
with tempfile.TemporaryDirectory() as t:
    s = mk(t, [("eth0", "eth", 1), ("eth1", "eth", 1), ("eth2", "eth", 0), ("eth3", "eth", 0)])
    env, nm, st, sf = run(t, s, BASE)
    check("VM: management = eth0, SPAN = eth1,eth2,eth3", env["MGMT"] == "eth0" and env["CAP"] == "eth1,eth2,eth3")
    check("VM: ethernet keyfile (DHCP)", "method=auto" in open(os.path.join(nm, "system-connections", "otsense-mgmt.nmconnection")).read())
    check("VM: slot imported to state, blanked afterwards (dry run keeps file)", os.path.exists(os.path.join(st, "slot.json")))

# 3. static IP
with tempfile.TemporaryDirectory() as t:
    s = mk(t, [("eth0", "eth", 1), ("eth1", "eth", 1)])
    env, nm, st, sf = run(t, s, dict(BASE, mode="static", ip_cidr="10.1.2.3/24", gateway="10.1.2.1", dns="10.1.2.1,8.8.8.8"))
    kf = open(os.path.join(nm, "system-connections", "otsense-mgmt.nmconnection")).read()
    check("static: address1 + dns", "address1=10.1.2.3/24,10.1.2.1" in kf and "dns=10.1.2.1;8.8.8.8;" in kf)

# 4. manual choice made on the console wins over automatic
with tempfile.TemporaryDirectory() as t:
    s = mk(t, [("eth0", "eth", 1), ("eth1", "eth", 1), ("eth2", "eth", 1), ("wlan0", "wifi", 1)])
    os.makedirs(os.path.join(t, "state"))
    stamp(os.path.join(t, "otsense-slot.bin"), BASE)     # not a new stamp... remove it so ports.json is not reset
    os.remove(os.path.join(t, "otsense-slot.bin"))
    json.dump(dict(BASE, wifi_ssid="x", wifi_psk="12345678"), open(os.path.join(t, "state", "slot.json"), "w"))
    env, nm, st, sf = run(t, s, None, ports={"mgmt": "eth2", "span": ["eth0", "eth1"], "manual": True})
    check("manual: mgmt=eth2 span=eth0,eth1", env["MGMT"] == "eth2" and env["CAP"] == "eth0,eth1" and env["MANUAL"] == "1")

# 5. a port that disappeared is dropped from a manual choice; a NEW stamp resets old manual choices
with tempfile.TemporaryDirectory() as t:
    s = mk(t, [("eth0", "eth", 1)])
    os.makedirs(os.path.join(t, "state"))
    json.dump(BASE, open(os.path.join(t, "state", "slot.json"), "w"))
    env, nm, st, sf = run(t, s, None, ports={"mgmt": "eth0", "span": ["eth5"], "manual": True})
    check("manual: missing port dropped", env["CAP"] == "" and env["MANUAL"] == "1")
with tempfile.TemporaryDirectory() as t:
    s = mk(t, [("eth0", "eth", 1), ("eth1", "eth", 1), ("eth2", "eth", 1)])
    env, nm, st, sf = run(t, s, BASE, ports={"mgmt": "eth2", "span": ["eth0"], "manual": True})
    check("new stamp resets manual choice", env["MANUAL"] == "0" and env["MGMT"] == "eth0")

# 6. blank slot is ignored, unstamped sensor starts in manual-config mode
with tempfile.TemporaryDirectory() as t:
    s = mk(t, [("eth0", "eth", 1), ("wlan0", "wifi", 1)])
    sf = os.path.join(t, "otsense-slot.bin"); open(sf, "wb").write(b"OTSENSE_SLOT_V1\n" + bytes(65520))
    env, nm, st, sf = run(t, s, None)
    check("blank slot: CONFIGURED=0, wired = management", env["CONFIGURED"] == "0" and env["MGMT"] == "eth0")
    check("blank slot: a web password was generated", len(env["WEBPW"]) >= 8)

# 7. bad characters in the Wi-Fi name must not reach the file
spec = importlib.util.spec_from_file_location("prep", PREP); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
try:
    m.nm_keyfile_wifi("wlan0", {"wifi_ssid": "a\nb[connection]", "wifi_psk": "12345678"}); ok = False
except ValueError:
    ok = True
check("newline in SSID rejected (no keyfile injection)", ok)
print("\n%d failure(s)" % check.bad)
sys.exit(1 if check.bad else 0)
