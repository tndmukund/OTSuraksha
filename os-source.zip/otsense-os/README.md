# OT Sense OS - one sensor system for Raspberry Pi, VMs and PCs

One recipe, two files:

| File | Goes on | Boots on |
|---|---|---|
| `otsense-sensor-rpi.img.xz` | SD card (Raspberry Pi 3 / 4 / 5) | the Pi |
| `otsense-sensor.img` | VM disk, or written to an SSD / USB stick | VMware, Hyper-V, VirtualBox, Proxmox/KVM, mini-PC, server (BIOS and UEFI, Secure Boot off) |

(An OVA is only a VM wrapper; a Pi SD card cannot use it. Both files contain the same sensor, same screen, same settings.)

## What the sensor does when it powers on
1. Reads its site settings (site name, central address, token, Wi-Fi) from a small file `otsense-slot.bin` that central made for this site, then blanks the file.
2. Chooses the ports. **Automatic rules** (you can override on the screen):
   * Wi-Fi name given, or a Wi-Fi card present with settings -> **Wi-Fi = management**, every wired port = **SPAN / capture**. (Raspberry Pi: Wi-Fi to central, its Ethernet port to the switch mirror port.)
   * No Wi-Fi -> first wired port = management, **all other wired ports = SPAN** (VM with 4 NICs: 1 management + 3 SPAN; Pi with USB adapters: add as many SPAN ports as you plug in).
3. A SPAN port gets no IP, no DHCP, IPv6 off, promiscuous on. Only the management port ever sends anything.
4. Starts the sensor and shows everything on the display.

## The screen (HDMI / VM console)
Web address, web password, central address, **connection test to central**, clock sync, every port with link / address / role / packets.
Keys: **W** Wi-Fi (scan, pick, type password), **P** ports (choose management + any number of SPAN), **N** fixed IP or DHCP, **C** central address + token, **T** test central, **R** restart, **L** login, **X** reboot/off. Alt+F2 = text login (user `user`).
So even with no file at all you can set everything with a keyboard.

## Build the images (once, free, on GitHub)
1. In your GitHub repo upload `os-source.zip` (repo root) and `build-os.yml` (into `.github/workflows/`).
2. Actions -> **Build OT Sense OS images** -> Run workflow (about 30-60 min).
3. The Release has both files. Paste their links in central: Sites -> Base images.

## Make a sensor for a site
Central -> Sites -> Build a ready-to-install sensor. Fill site, central address, (Wi-Fi name, password, country), pick platform:
* **Raspberry Pi**: flash `otsense-sensor-rpi.img.xz` once (Raspberry Pi Imager -> Use custom, or balenaEtcher). Re-insert the card, copy `otsense-slot.bin` from the downloaded zip onto the `bootfs` drive. Done. Same card image for every site.
* **VM / PC (x86)**: choose "Proxmox / KVM / raw disk", "VirtualBox" or "Hyper-V" -> you get the image already stamped.

## Test first on VMware Workstation (before the real Pi)
1. In central build a sensor with platform "Proxmox / KVM ... raw disk (.img)". Download it.
2. Convert once: `qemu-img convert -f raw -O vmdk otsense-sensor-<site>.img sensor.vmdk` (QEMU for Windows) - or VirtualBox: `VBoxManage convertfromraw otsense-sensor-<site>.img sensor.vdi --format VDI`.
3. New VM: Linux, Debian 12 64-bit, 2 CPU, 2-4 GB, use existing disk `sensor.vmdk`, **4 network adapters** (1 = Bridged to your LAN, 2-4 = LAN segments / extra VMnets). Keep BIOS firmware (no Secure Boot).
4. To test Wi-Fi management: plug a USB Wi-Fi adapter and connect it to the VM (VM menu -> Removable devices). Then press **W** on the VM screen.
5. Power on. Within about a minute the screen shows the web address; the site turns green in central.

## Honest limits (read before relying on it)
* **Nothing here was built or booted on real hardware.** The build machine I used has no internet and no debootstrap. What I did run: the boot logic against fake network cards (16 checks), the console screen in a test terminal, the central build/stamp round trip, and multi-port capture on the loopback. The first real build and first boot are the real test - send me the GitHub log or a photo of the screen if anything fails.
* Wi-Fi password lives in the site file (blanked after first boot) and in the root-only NetworkManager file on the card. Anyone who steals the SD card can read it. Use a dedicated Wi-Fi for sensors.
* A Wi-Fi card can never be a SPAN port (it does not receive mirrored traffic).
* A Raspberry Pi has no battery clock: it needs NTP (or a router that gives time) to talk to central over TLS. The screen shows "Clock: NOT synchronised" if that is the problem. Pi 3 Ethernet shares the USB bus: use Pi 4/5, and an x86 mini-PC for heavily loaded mirror ports.
* Secure Boot must be off on x86 (unsigned boot loader).
* Image uses Raspberry Pi OS Lite "latest" as base. If a future release changes its first-boot steps, the build may need a small fix.
* The old `sensor-image/run-sensor.sh` calls `otsense.py netapply`, which does not exist in the `otsense.py` of this zip (so it silently did nothing). The new image does not use it.

## Remote access (SRA) port - own IP / VLAN for engineer sessions
Remote sessions that engineers start from central (RDP in the browser, helper app) can leave the sensor through a **dedicated port** instead of the management port.
* **Set it on the sensor screen**: button **Remote access port (SRA)** (text screen: key **S**; also key **R** inside Ports). Choose a free wired port, an optional **VLAN** (1-4094) and a **fixed IP address with prefix** (e.g. `10.20.0.5/24`); a gateway is optional (only for devices on other networks, used by the SRA port alone).
* VM: add one more network adapter for it. Raspberry Pi: plug in a USB Ethernet adapter.
* The SRA port never captures traffic, never becomes the default route and never answers on the management address. If a target cannot be reached through the SRA port the session fails - it is **never** sent out of the management port.
* Technically: own routing table 190, rule for the SRA source address (sensor program) and for guacd (browser remote desktop, user `nobody`). Settings: `/var/lib/otsense/sra.json`.
* Not done here: central cannot yet stamp the SRA port into a built image (set it on the screen once per sensor).
