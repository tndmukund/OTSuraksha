#!/usr/bin/env bash
# Wraps the sensor ISO into an OVA: a ready-made VM (2 CPU, 4 GB RAM, 4 network ports, the ISO in the CD drive).
# usage: make-ova.sh <otsense-sensor.iso> <otsense-sensor.ova>
# The ISO is stored inside the OVA unchanged and uncompressed, and there is NO manifest (.mf) on purpose:
# central writes each site's settings into the 64 KB slot inside the file, which a checksum would reject.
set -euo pipefail
ISO="${1:?usage: make-ova.sh <iso> <ova>}"; OVA="${2:?usage: make-ova.sh <iso> <ova>}"
[ -f "$ISO" ] || { echo "ISO not found: $ISO"; exit 1; }
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
SIZE="$(stat -c %s "$ISO")"; cp -f "$ISO" "$W/otsense-sensor.iso" 2>/dev/null || ln -f "$ISO" "$W/otsense-sensor.iso"
nic() { # $1 = instance id, $2 = network name, $3 = description
cat <<XML
      <Item>
        <rasd:AddressOnParent>$(( $1 - 6 ))</rasd:AddressOnParent>
        <rasd:AutomaticAllocation>true</rasd:AutomaticAllocation>
        <rasd:Connection>$2</rasd:Connection>
        <rasd:Description>$3</rasd:Description>
        <rasd:ElementName>Network adapter $(( $1 - 6 ))</rasd:ElementName>
        <rasd:InstanceID>$1</rasd:InstanceID>
        <rasd:ResourceSubType>E1000</rasd:ResourceSubType>
        <rasd:ResourceType>10</rasd:ResourceType>
      </Item>
XML
}
cat > "$W/otsense-sensor.ovf" <<XML
<?xml version="1.0" encoding="UTF-8"?>
<Envelope xmlns="http://schemas.dmtf.org/ovf/envelope/1" xmlns:ovf="http://schemas.dmtf.org/ovf/envelope/1" xmlns:rasd="http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_ResourceAllocationSettingData" xmlns:vssd="http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_VirtualSystemSettingData" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <References>
    <File ovf:href="otsense-sensor.iso" ovf:id="file1" ovf:size="$SIZE"/>
  </References>
  <NetworkSection>
    <Info>Networks</Info>
    <Network ovf:name="Management"><Description>Management: reaches central (use a normal network)</Description></Network>
    <Network ovf:name="Capture"><Description>Capture (SPAN / mirror port): receive only, never transmits</Description></Network>
    <Network ovf:name="Spare1"><Description>Spare network 1</Description></Network>
    <Network ovf:name="Spare2"><Description>Spare network 2</Description></Network>
  </NetworkSection>
  <VirtualSystem ovf:id="otsense-sensor">
    <Info>OT Sense sensor</Info>
    <Name>OT Sense sensor</Name>
    <OperatingSystemSection ovf:id="96">
      <Info>Debian GNU/Linux, 64-bit</Info>
    </OperatingSystemSection>
    <VirtualHardwareSection>
      <Info>2 CPU, 4 GB RAM, 4 network ports, ISO in the CD drive</Info>
      <System>
        <vssd:ElementName>Virtual Hardware Family</vssd:ElementName>
        <vssd:InstanceID>0</vssd:InstanceID>
        <vssd:VirtualSystemIdentifier>otsense-sensor</vssd:VirtualSystemIdentifier>
        <vssd:VirtualSystemType>vmx-13</vssd:VirtualSystemType>
      </System>
      <Item>
        <rasd:AllocationUnits>hertz * 10^6</rasd:AllocationUnits>
        <rasd:Description>Number of Virtual CPUs</rasd:Description>
        <rasd:ElementName>2 virtual CPU(s)</rasd:ElementName>
        <rasd:InstanceID>1</rasd:InstanceID>
        <rasd:ResourceType>3</rasd:ResourceType>
        <rasd:VirtualQuantity>2</rasd:VirtualQuantity>
      </Item>
      <Item>
        <rasd:AllocationUnits>byte * 2^20</rasd:AllocationUnits>
        <rasd:Description>Memory Size</rasd:Description>
        <rasd:ElementName>4096MB of memory</rasd:ElementName>
        <rasd:InstanceID>2</rasd:InstanceID>
        <rasd:ResourceType>4</rasd:ResourceType>
        <rasd:VirtualQuantity>4096</rasd:VirtualQuantity>
      </Item>
      <Item>
        <rasd:Address>1</rasd:Address>
        <rasd:Description>IDE Controller</rasd:Description>
        <rasd:ElementName>IDE Controller 1</rasd:ElementName>
        <rasd:InstanceID>3</rasd:InstanceID>
        <rasd:ResourceType>5</rasd:ResourceType>
      </Item>
      <Item>
        <rasd:AddressOnParent>0</rasd:AddressOnParent>
        <rasd:AutomaticAllocation>true</rasd:AutomaticAllocation>
        <rasd:Description>CD-ROM drive with the sensor ISO</rasd:Description>
        <rasd:ElementName>CD/DVD Drive 1</rasd:ElementName>
        <rasd:HostResource>ovf:/file/file1</rasd:HostResource>
        <rasd:InstanceID>4</rasd:InstanceID>
        <rasd:Parent>3</rasd:Parent>
        <rasd:ResourceType>15</rasd:ResourceType>
      </Item>
$(nic 7 Management "Management port")
$(nic 8 Capture "Capture port (SPAN)")
$(nic 9 Spare1 "Spare port 1")
$(nic 10 Spare2 "Spare port 2")
    </VirtualHardwareSection>
  </VirtualSystem>
</Envelope>
XML
rm -f "$OVA"
tar --format=ustar --owner=0 --group=0 -C "$W" -cf "$OVA" otsense-sensor.ovf otsense-sensor.iso
# self-check: the file list, and exactly ONE config slot (central refuses the file otherwise)
tar -tvf "$OVA"
N="$(python3 - "$OVA" <<'PY'
import sys
M=b"OTSENSE_SLOT_V1\n"; n=0; tail=b""
with open(sys.argv[1],"rb") as f:
    while True:
        c=f.read(8<<20)
        if not c: break
        b=tail+c; n+=b.count(M); tail=b[-15:]
print(n)
PY
)"
[ "$N" = 1 ] || { rm -f "$OVA"; echo "SELF-CHECK FAILED: found $N config slots in the OVA (expected 1)"; exit 1; }
ls -lh "$OVA"; echo "OK: $OVA"
