#!/usr/bin/env python3
"""OT Sense OS - on-screen console (HDMI / VM screen / serial). Runs on tty1 instead of the login prompt.
Keys:  W Wi-Fi network   P Ports (management / SPAN / remote access)   N Management IP   S Remote access (SRA) port   C Central settings   T Test central
       R Restart sensor   L Login shell (or Alt+F2)   X Reboot / shut down
Everything you change is saved and applied at once; nothing needs a keyboard shortcut you cannot see on the screen."""
import curses, json, os, re, shlex, socket, ssl, subprocess, sys, threading, time, urllib.request

STATE = os.environ.get("OTS_STATE", "/var/lib/otsense")
RUN = os.environ.get("OTS_RUN", "/run/otsense")
SYS = os.environ.get("OTS_SYS", "/sys/class/net")
PREP = os.environ.get("OTS_PREP", "/opt/otsense/otsense-prep.py")
DRY = os.environ.get("OTS_DRY") == "1"


# ------------------------------------------------------------------ data
def rd(p, d=""):
    try:
        with open(p) as f:
            return f.read().strip()
    except OSError:
        return d


def load_json(p):
    try:
        with open(p) as f:
            x = json.load(f)
        return x if isinstance(x, dict) else {}
    except (OSError, ValueError):
        return {}


def save_json(p, d):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(d, f, indent=1)


def env():
    out = {}
    for ln in rd(os.path.join(RUN, "env")).splitlines():
        if "=" in ln:
            k, v = ln.split("=", 1)
            try:
                out[k] = shlex.split(v)[0] if v else ""
            except ValueError:
                out[k] = v
    return out


def cmd(c, t=20):
    if DRY:
        return ""
    try:
        return subprocess.run(c, capture_output=True, text=True, timeout=t).stdout
    except Exception:
        return ""


def ips():
    d = {}
    for ln in cmd(["ip", "-o", "-4", "addr", "show"]).splitlines():
        p = ln.split()
        if len(p) > 3:
            d.setdefault(p[1], []).append(p[3].split("/")[0])
    return d


_prep = []


def nics():
    if not _prep:
        import importlib.util
        spec = importlib.util.spec_from_file_location("prep", PREP)
        m = importlib.util.module_from_spec(spec)
        os.environ.setdefault("OTS_SYS", SYS)
        spec.loader.exec_module(m)
        m.SYS = SYS
        _prep.append(m)
    return _prep[0].discover()


def roles():
    e = env()
    return e.get("MGMT", ""), [x for x in e.get("CAP", "").split(",") if x]


_sra = []


def sra():
    """The shared remote-access (SRA) module otsense-sra.py (settings in sra.json, same file the boot script reads)."""
    if not _sra:
        import importlib.util
        spec = importlib.util.spec_from_file_location("otsra", os.environ.get("OTS_SRA", os.path.join(os.path.dirname(os.path.abspath(__file__)), "otsense-sra.py")))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        m.STATE, m.CFG, m.SYS, m.DRY = STATE, os.path.join(STATE, "sra.json"), SYS, DRY
        _sra.append(m)
    return _sra[0]


def sra_cfg():
    """-> (port, settings) of the configured remote-access port that is really in use now (env SRA written by otsense-prep)."""
    return env().get("SRA", ""), sra().load()


def rx(n):
    return int(rd("%s/%s/statistics/rx_packets" % (SYS, n), "0") or 0)


_central = {"t": 0, "txt": "not tested yet", "ok": None}


def check_central(force=False):
    """TCP + TLS + one HTTP request to central (any HTTP answer = reachable). Runs in a thread, never blocks the screen."""
    cfg = load_json(os.path.join(STATE, "slot.json"))
    url = cfg.get("central") or env().get("CENTRAL", "")
    if not url:
        _central.update(txt="no central address set (press C)", ok=False, t=time.time())
        return
    if not force and time.time() - _central["t"] < 20:
        return
    _central["t"] = time.time()

    def work():
        try:
            ca = env().get("CAFILE") or None
            ctx = ssl.create_default_context(cafile=ca) if ca and os.path.exists(ca) else ssl.create_default_context()
            r = urllib.request.urlopen(url, timeout=6, context=ctx)
            _central.update(txt="reachable (HTTP %s)" % r.status, ok=True)
        except urllib.error.HTTPError as e:
            _central.update(txt="reachable (HTTP %s)" % e.code, ok=True)
        except Exception as e:
            _central.update(txt="NOT reachable: %s" % str(getattr(e, "reason", e))[:60], ok=False)
    threading.Thread(target=work, daemon=True).start()


def apply_now(msg_cb):
    msg_cb("Applying ...")
    if not DRY:
        subprocess.run(["systemctl", "restart", "otsense-prep.service"], timeout=60)
        subprocess.run(["systemctl", "restart", "otsense-sensor.service"], timeout=60)
    msg_cb("Applied.")


# ------------------------------------------------------------------ ui helpers
def put(w, y, x, s, a=0):
    h, wd = w.getmaxyx()
    if 0 <= y < h and x < wd:
        try:
            w.addnstr(y, x, s, max(0, wd - x - 1), a)
        except curses.error:
            pass


def prompt(w, title, label, default="", secret=False):
    """Single line input. Returns text, or None when Esc is pressed."""
    buf = list(default)
    curses.curs_set(1)
    w.timeout(-1)
    try:
        while True:
            w.erase()
            put(w, 1, 2, title, curses.A_BOLD)
            put(w, 3, 2, label)
            put(w, 5, 2, "> " + ("*" * len(buf) if secret else "".join(buf)))
            put(w, 7, 2, "Enter = OK     Esc = cancel", curses.A_DIM)
            w.refresh()
            k = w.getch()
            if k in (10, 13, curses.KEY_ENTER):
                return "".join(buf)
            if k == 27:
                return None
            if k in (curses.KEY_BACKSPACE, 127, 8):
                if buf:
                    buf.pop()
            elif 32 <= k < 127 or 160 <= k < 256:
                buf.append(chr(k))
    finally:
        curses.curs_set(0)
        w.timeout(1500)


def message(w, title, lines, wait=True):
    w.erase()
    put(w, 1, 2, title, curses.A_BOLD)
    for i, l in enumerate(lines):
        put(w, 3 + i, 2, l)
    if wait:
        put(w, 4 + len(lines), 2, "Press any key", curses.A_DIM)
    w.refresh()
    if wait:
        w.timeout(-1)
        w.getch()
        w.timeout(1500)


def choose(w, title, items, hint="Up/Down + Enter, Esc = back"):
    """items: list of strings. Returns index or None."""
    i = 0
    w.timeout(-1)
    try:
        while True:
            w.erase()
            put(w, 1, 2, title, curses.A_BOLD)
            for n, t in enumerate(items[:18]):
                put(w, 3 + n, 2, ("> " if n == i else "  ") + t, curses.A_REVERSE if n == i else 0)
            put(w, 4 + min(len(items), 18), 2, hint, curses.A_DIM)
            w.refresh()
            k = w.getch()
            if k in (curses.KEY_UP, ord("k")):
                i = (i - 1) % len(items)
            elif k in (curses.KEY_DOWN, ord("j")):
                i = (i + 1) % len(items)
            elif k in (10, 13, curses.KEY_ENTER):
                return i
            elif k == 27:
                return None
    finally:
        w.timeout(1500)


# ------------------------------------------------------------------ actions
def slot_update(**kw):
    p = os.path.join(STATE, "slot.json")
    d = load_json(p)
    d.update(kw)
    save_json(p, d)


def wifi_menu(w, note):
    ns = [n for n in nics() if n["wifi"]]
    if not ns:
        message(w, "Wi-Fi", ["No Wi-Fi card found on this device.", "Raspberry Pi 4/5 have one built in; on a PC/VM plug in a USB Wi-Fi adapter."])
        return
    ifn = ns[0]["name"]
    cfg = load_json(os.path.join(STATE, "slot.json"))
    cc = str(cfg.get("wifi_country") or "").upper()
    if not re.match(r"^[A-Z]{2}$", cc):
        x = prompt(w, "Wi-Fi country", "Two-letter country code of the place where the sensor is (e.g. IN, US, GB, DE):")
        if not x or not re.match(r"^[A-Za-z]{2}$", x):
            return
        cc = x.upper()
        slot_update(wifi_country=cc)
    message(w, "Wi-Fi", ["Searching for networks on %s ..." % ifn, "(about 10 seconds)"], wait=False)
    cmd(["rfkill", "unblock", "wifi"])
    cmd(["iw", "reg", "set", cc])
    out = cmd(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "ifname", ifn, "--rescan", "yes"], 30)
    nets, seen = [], set()
    for ln in out.splitlines():
        p = re.split(r"(?<!\\):", ln)
        if len(p) >= 3 and p[0] and p[0] not in seen:
            seen.add(p[0])
            nets.append((p[0].replace("\\:", ":"), p[1], p[2] or "open"))
    nets.sort(key=lambda x: -int(x[1] or 0))
    items = ["%-28s %3s%%  %s" % (s[:28], g, sec[:14]) for s, g, sec in nets] + ["[ Type the name of a hidden network ]"]
    i = choose(w, "Choose the Wi-Fi network", items)
    if i is None:
        return
    hidden = i == len(nets)
    ssid = prompt(w, "Hidden network", "Network name (SSID):") if hidden else nets[i][0]
    if not ssid:
        return
    psk = ""
    if hidden or nets[i][2] != "open":
        psk = prompt(w, "Wi-Fi password", "Password for %s (8-63 characters):" % ssid, secret=True)
        if psk is None:
            return
        if not (8 <= len(psk) <= 63 or re.match(r"^[0-9A-Fa-f]{64}$", psk)):
            message(w, "Wi-Fi", ["The password must be 8 to 63 characters."])
            return
    slot_update(wifi_ssid=ssid, wifi_psk=psk, wifi_hidden=hidden, mgmt="wifi")
    # a manual port choice would keep the old roles: make Wi-Fi the management port and keep wired ports as SPAN
    pp = os.path.join(STATE, "ports.json")
    if load_json(pp).get("manual"):
        os.remove(pp)
    apply_now(note)
    for _ in range(25):
        a = ips().get(ifn)
        if a:
            message(w, "Wi-Fi", ["Connected to %s" % ssid, "Management address: %s" % a[0], "Web page: https://%s:8080" % a[0]])
            return
        time.sleep(1)
    message(w, "Wi-Fi", ["No address yet from %s." % ssid, "Wrong password, weak signal, or the router blocks new devices.", "Try again with W, or check the password."])


def ports_menu(w, note):
    ns = nics()
    if not ns:
        message(w, "Ports", ["No network ports found."])
        return
    mg, sp = roles()
    sp_port = sra_cfg()[0]
    cur = {n["name"]: ("M" if n["name"] == mg else "S" if n["name"] in sp else "R" if n["name"] == sp_port else "-") for n in ns}
    i = 0
    w.timeout(-1)
    try:
        while True:
            w.erase()
            put(w, 1, 2, "Network ports", curses.A_BOLD)
            put(w, 2, 2, "M = management   S = SPAN / capture   R = remote access (SRA, own IP / VLAN)   U = unused   A = automatic   Enter = save", curses.A_DIM)
            for n, nic in enumerate(ns[:16]):
                r = cur[nic["name"]]
                rl = {"M": "MANAGEMENT", "S": "SPAN/capture", "R": "REMOTE ACCESS", "-": "unused"}[r]
                t = "%-10s %-9s %-18s %s" % (nic["name"], "Wi-Fi" if nic["wifi"] else "Ethernet", nic["mac"], rl)
                put(w, 4 + n, 2, ("> " if n == i else "  ") + t, curses.A_REVERSE if n == i else 0)
            put(w, 5 + min(len(ns), 16), 2, "A SPAN port carries no IP address and never sends anything. Wi-Fi cannot be a SPAN port.", curses.A_DIM)
            w.refresh()
            k = w.getch()
            nm = ns[i]["name"]
            if k in (curses.KEY_UP, ord("k")):
                i = (i - 1) % len(ns)
            elif k in (curses.KEY_DOWN, ord("j")):
                i = (i + 1) % len(ns)
            elif k in (ord("m"), ord("M")):
                for x in cur:
                    if cur[x] == "M":
                        cur[x] = "-"
                cur[nm] = "M"
            elif k in (ord("s"), ord("S")):
                if ns[i]["wifi"]:
                    message(w, "Ports", ["A Wi-Fi card cannot receive mirrored traffic.", "Use a wired port for SPAN."])
                else:
                    cur[nm] = "S"
            elif k in (ord("u"), ord("U")):
                cur[nm] = "-"
            elif k in (ord("r"), ord("R")):
                if ns[i]["wifi"]:
                    message(w, "Ports", ["A Wi-Fi card cannot be the remote-access port.", "Use a wired port."])
                else:
                    sra_menu(w, note, nm)
                    return
            elif k in (ord("a"), ord("A")):
                try:
                    os.remove(os.path.join(STATE, "ports.json"))
                except OSError:
                    pass
                apply_now(note)
                return
            elif k == 27:
                return
            elif k in (10, 13, curses.KEY_ENTER):
                m = [x for x in cur if cur[x] == "M"]
                s = [x for x in cur if cur[x] == "S"]
                if not m:
                    message(w, "Ports", ["Choose one management port (M) first."])
                    continue
                if not s:
                    message(w, "Ports", ["Note: no SPAN port chosen, so nothing will be captured."])
                save_json(os.path.join(STATE, "ports.json"), {"mgmt": m[0], "span": s, "manual": True})
                if sp_port and cur.get(sp_port) != "R":      # the remote-access port was given another role: switch SRA off
                    sra().clear_cfg()
                apply_now(note)
                return
    finally:
        w.timeout(1500)


def ip_menu(w, note):
    i = choose(w, "Management IP address", ["Automatic (DHCP)", "Fixed address"])
    if i is None:
        return
    if i == 0:
        slot_update(mode="dhcp", ip_cidr="", gateway="", dns="")
    else:
        cfg = load_json(os.path.join(STATE, "slot.json"))
        a = prompt(w, "Fixed address", "IP address with prefix, e.g. 192.168.1.50/24:", cfg.get("ip_cidr", ""))
        if not a or not re.match(r"^\d{1,3}(\.\d{1,3}){3}/\d{1,2}$", a):
            return
        g = prompt(w, "Fixed address", "Gateway, e.g. 192.168.1.1:", cfg.get("gateway", ""))
        if not g or not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", g):
            return
        d = prompt(w, "Fixed address", "DNS server(s), comma separated, e.g. 192.168.1.1:", cfg.get("dns", "") or g)
        if d is None:
            return
        slot_update(mode="static", ip_cidr=a, gateway=g, dns=d)
    apply_now(note)


def sra_menu(w, note, port=None):
    """Remote-access (SRA) port: pick the port, an optional VLAN and the fixed IP address. Engineer sessions from central leave here."""
    m = sra()
    ns = [n for n in nics() if not n["wifi"]]
    mg, _sp = roles()
    cands = [n["name"] for n in ns if n["name"] != mg]
    cur = m.load()
    if port is None:
        items = ["%s%s" % (n, "   (now the remote-access port)" if n == cur.get("port") else "") for n in cands] + ["Switch the remote-access port OFF"]
        if not cands:
            message(w, "Remote access (SRA)", ["No free wired port. The remote-access port needs its own network port:", "in a VM add a network adapter; on a Raspberry Pi plug in a USB Ethernet adapter."])
            return
        i = choose(w, "Which port is the REMOTE ACCESS (SRA) port?", items)
        if i is None:
            return
        if i == len(cands):
            m.clear_cfg()
            apply_now(note)
            return
        port = cands[i]
    v = prompt(w, "Remote access (SRA)", "VLAN number for this port (1-4094), empty = no VLAN:", str(cur.get("vlan") or "") if cur.get("port") == port else "")
    if v is None:
        return
    a = prompt(w, "Remote access (SRA)", "Fixed IP address with prefix, e.g. 10.20.0.5/24:", cur.get("ip_cidr", "") if cur.get("port") == port else "")
    if not a:
        return
    g = prompt(w, "Remote access (SRA)", "Gateway inside that network, empty = none (devices are on the same network):", cur.get("gateway", "") if cur.get("port") == port else "")
    if g is None:
        return
    c = {"port": port, "vlan": int(v) if v.strip().isdigit() else 0, "ip_cidr": a.strip(), "gateway": g.strip()}
    ok, why = m.validate(c, m.other_addresses(skip=(port, m.ifname(c))))
    if not ok:
        message(w, "Remote access (SRA)", [why])
        return
    m.save(c)
    apply_now(note)
    message(w, "Remote access (SRA)", ["Remote access port %s%s: %s%s" % (port, (" VLAN %s" % c["vlan"]) if c["vlan"] else "", c["ip_cidr"], (" via " + c["gateway"]) if c["gateway"] else ""),
                                      "", "Engineer sessions started from central now leave through this port.",
                                      "If the target is not reachable through it, the session fails (it never uses the management port)."])


def central_menu(w, note):
    cfg = load_json(os.path.join(STATE, "slot.json"))
    s = prompt(w, "Central settings", "Site name:", cfg.get("site", ""))
    if s is None:
        return
    c = prompt(w, "Central settings", "Central address, e.g. https://central.example.com :", cfg.get("central", ""))
    if c is None or (c and not re.match(r"^https?://[^/\s]+$", c)):
        message(w, "Central settings", ["The address must look like https://central.example.com (no path)."])
        return
    t = prompt(w, "Central settings", "Site token (from central, Sites tab). Leave empty to keep the current one:", secret=True)
    if t is None:
        return
    slot_update(site=s, central=c.rstrip("/"), token=t or cfg.get("token", ""))
    apply_now(note)
    check_central(True)


def power_menu(w):
    i = choose(w, "Power", ["Reboot", "Shut down", "Cancel"])
    if i == 0 and not DRY:
        subprocess.run(["systemctl", "reboot"])
    elif i == 1 and not DRY:
        subprocess.run(["systemctl", "poweroff"])


# ------------------------------------------------------------------ main screen
def draw(w, msg):
    w.erase()
    e = env()
    cfg = load_json(os.path.join(STATE, "slot.json"))
    mg, sp = roles()
    a = ips()
    try:
        sra_p, sra_c = sra_cfg()
        sra_i = sra().ifname(sra_c) if sra_p else ""
    except Exception:
        sra_p, sra_c, sra_i = "", {}, ""
    put(w, 0, 1, "OT Sense sensor", curses.A_BOLD)
    put(w, 0, 20, "site: %s     host: %s" % (e.get("SITE") or cfg.get("site") or "(not set)", e.get("HOST", "")))
    mip = (a.get(mg) or [""])[0]
    put(w, 2, 1, "Web page:   " + ("https://%s:8080" % mip if mip else "(waiting for an address on the management port)"), curses.A_BOLD)
    put(w, 3, 1, "Password:   %s        (browser certificate warning is normal: Advanced > continue)" % e.get("WEBPW", ""))
    put(w, 4, 1, "Central:    %s" % (cfg.get("central") or e.get("CENTRAL") or "(not set)"))
    check_central()
    put(w, 5, 1, "Connection: %s" % _central["txt"], curses.A_BOLD if _central["ok"] else 0)
    ntp = cmd(["timedatectl", "show", "-p", "NTPSynchronized", "--value"]).strip() if not DRY else ""
    put(w, 6, 1, "Clock:      %s   %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), "(synchronised)" if ntp == "yes" else "(NOT synchronised - TLS to central can fail; set an NTP server)" if ntp else ""))
    put(w, 8, 1, "%-10s %-9s %-7s %-16s %-13s %s" % ("PORT", "TYPE", "LINK", "ADDRESS", "ROLE", "PACKETS"), curses.A_UNDERLINE)
    y = 9
    try:
        ns = nics()
    except Exception:
        ns = []
    for n in ns[:8]:
        r = "management" if n["name"] == mg else "SPAN/capture" if n["name"] in sp else "remote access" if n["name"] == sra_p else "unused"
        up = rd("%s/%s/carrier" % (SYS, n["name"])) == "1"
        adr = (a.get(sra_i if n["name"] == sra_p else n["name"]) or ["-"])[0]
        put(w, y, 1, "%-10s %-9s %-7s %-16s %-13s %s" % (n["name"], "Wi-Fi" if n["wifi"] else "Ethernet", "up" if up else "down",
            adr, r, rx(n["name"]) if r == "SPAN/capture" else ""))
        y += 1
    if sra_p:
        put(w, y, 1, "Remote access (SRA): %s%s  %s%s - engineer sessions from central leave through this port" % (sra_p, (" VLAN %s" % sra_c.get("vlan")) if sra_c.get("vlan") else "", sra_c.get("ip_cidr", ""), (" gw " + sra_c["gateway"]) if sra_c.get("gateway") else ""), curses.A_DIM)
        y += 1
    if not sp:
        put(w, y + 1, 1, "No SPAN / capture port: nothing is being captured. Press P to choose one.", curses.A_BOLD)
    h, _ = w.getmaxyx()
    put(w, h - 4, 1, "[W] Wi-Fi [P] Ports [N] IP [S] Remote access [C] Central [T] Test [R] Restart [G] Graphical [L] Login [X] Off", curses.A_REVERSE)
    put(w, h - 3, 1, msg[0] if msg[0] else "Alt+F2 = text login (user: user).  Everything is saved when you press Enter.", curses.A_DIM)
    w.refresh()


def main(w):
    curses.curs_set(0)
    w.timeout(1500)
    msg = [""]

    def note(t):
        msg[0] = t
        draw(w, msg)
    while True:
        draw(w, msg)
        k = w.getch()
        if k == -1:
            continue
        msg[0] = ""
        c = chr(k).lower() if 0 < k < 256 else ""
        if c == "w":
            wifi_menu(w, note)
        elif c == "p":
            ports_menu(w, note)
        elif c == "n":
            ip_menu(w, note)
        elif c == "s":
            sra_menu(w, note)
        elif c == "c":
            central_menu(w, note)
        elif c == "t":
            check_central(True)
            msg[0] = "Testing the connection to central ..."
        elif c == "r":
            if not DRY:
                subprocess.run(["systemctl", "restart", "otsense-sensor.service"])
            msg[0] = "Sensor restarted."
        elif c == "g":                       # back to the graphical screen (otsense-screen.sh starts it again when this program ends)
            if os.path.exists("/usr/bin/Xorg") and os.path.exists("/usr/bin/xinit"):
                try:
                    os.remove("/run/otsense/no-gui")
                except OSError:
                    pass
                if not DRY:
                    raise SystemExit(0)
                msg[0] = "(dry run) would switch to the graphical screen."
            else:
                msg[0] = "The graphical screen is not installed in this image."
        elif c == "x":
            power_menu(w)
        elif c == "l":
            curses.endwin()
            if not DRY:
                os.system("/bin/login")
            w.refresh()


if __name__ == "__main__":
    while True:
        try:
            curses.wrapper(main)
        except KeyboardInterrupt:
            pass
        except Exception as ex:           # never leave the screen dead: show the error and start again
            print("console error:", ex, file=sys.stderr)
            time.sleep(3)
        if DRY:
            break
