#!/usr/bin/env python3
"""OT Sense OS - graphical screen (buttons and windows, full screen). Same look and same buttons as the sensor ISO / OVA screen.
Started by otsense-screen.sh on tty1. It reuses the data and settings code of otsense-console.py (the text screen), so both always agree.
If the graphics cannot start, the text screen takes over by itself."""
import importlib.util, os, re, sys, threading, time
import tkinter as tk
from tkinter import simpledialog, messagebox, scrolledtext

D = os.environ.get("D", "/opt/otsense")
spec = importlib.util.spec_from_file_location("otc", os.path.join(D, "otsense-console.py"))
otc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(otc)

BG, PANEL, FG, CYAN, YEL = "#101820", "#1b2733", "#e8eef4", "#5ac8fa", "#ffd24a"
F, FB, FM = ("DejaVu Sans", 12), ("DejaVu Sans", 12, "bold"), ("DejaVu Sans Mono", 11)

root = tk.Tk()
root.title("OT Sense")
root.configure(bg=BG)
root.attributes("-fullscreen", True)
root.config(cursor="arrow")


def panel(title):
    f = tk.LabelFrame(root, text=" %s " % title, bg=PANEL, fg=CYAN, font=FB, bd=2, labelanchor="nw")
    f.pack(fill="x", padx=14, pady=5)
    lb = tk.Label(f, bg=PANEL, fg=FG, font=FM, justify="left", anchor="w")
    lb.pack(fill="x", padx=8, pady=4)
    return lb


hdr = tk.Label(root, text="", bg=BG, fg="#ff8cf0", font=("DejaVu Sans", 16, "bold"), anchor="w")
hdr.pack(fill="x", padx=14, pady=(10, 2))
lbl_if, lbl_sv, lbl_sr = panel("Interfaces"), panel("Services"), panel("Site  (settings from central)")
big = tk.Label(root, text="", bg=BG, fg=YEL, font=("DejaVu Sans", 15, "bold"), anchor="w")
big.pack(fill="x", padx=14, pady=4)
ntp_cache = [0.0, ""]


def refresh():
    try:
        e, cfg = otc.env(), otc.load_json(os.path.join(otc.STATE, "slot.json"))
        mg, sp = otc.roles()
        a = otc.ips()
        site = e.get("SITE") or cfg.get("site") or ""
        hdr.config(text="OT Sense Appliance     Site: %s     %s" % (site or "not set", time.strftime("%a %d %b %Y %H:%M:%S")))
        try:
            ns = otc.nics()
        except Exception:
            ns = []
        rows = []
        for n in ns[:8]:
            r = "MGMT" if n["name"] == mg else "SPAN" if n["name"] in sp else "-"
            up = otc.rd("%s/%s/carrier" % (otc.SYS, n["name"])) == "1"
            ip = (a.get(n["name"]) or [""])[0]
            tail = ("ip %s" % ip) if r == "MGMT" and ip else "waiting for an address..." if r == "MGMT" else "capture, no IP   rx packets %s" % otc.rx(n["name"]) if r == "SPAN" else ""
            rows.append("[ %-7s ] %-5s %-5s %-8s %s" % (n["name"], r, "UP" if up else "DOWN", "Wi-Fi" if n["wifi"] else "", tail))
        lbl_if.config(text="\n".join(rows) or "No network port found - add a network adapter.")
        mip = (a.get(mg) or [""])[0]
        url = "https://%s:8080" % mip if mip else "waiting for an address"
        otc.check_central()
        active = (otc.cmd(["systemctl", "is-active", "otsense-sensor.service"]) or "?").strip()
        lbl_sv.config(text="Sensor : %s\nWeb page : %s\nCentral : %s   (%s)" % ("Active" if active == "active" else "NOT running (%s) - see Show log" % active, url,
                      cfg.get("central") or e.get("CENTRAL") or "not set - press 'Central server'", otc._central["txt"]))
        now = time.time()
        if now - ntp_cache[0] > 10:
            ntp_cache[0] = now
            ntp_cache[1] = otc.cmd(["timedatectl", "show", "-p", "NTPSynchronized", "--value"]).strip()
        lbl_sr.config(text="Site name   : %s\nCentral     : %s\nSensor name : %s\nIP address  : %s %s\nTime (NTP)  : synchronised: %s" % (
            site or "not set", cfg.get("central") or e.get("CENTRAL") or "not set", e.get("HOST") or os.uname()[1],
            "DHCP" if (cfg.get("mode") or "dhcp") != "static" else "fixed", mip or "waiting...", {"yes": "yes", "no": "no"}.get(ntp_cache[1], "?")))
        big.config(text=("Open  %s   password:  %s" % (url, e.get("WEBPW", "..."))) if mip else "Waiting for an IP address on the management port...")
    except Exception as ex:
        big.config(text="screen error: %s" % ex)
    root.after(2000, refresh)


def show(title, text):
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("720x330+30+30")
    tk.Button(w, text="Close  (Esc)", font=FB, bg="#2d4a66", fg="white", height=2, command=w.destroy).pack(side="bottom", fill="x", padx=6, pady=6)
    t = scrolledtext.ScrolledText(w, bg="black", fg=FG, font=FM)
    t.insert("1.0", text)
    t.config(state="disabled")
    t.pack(side="top", fill="both", expand=True, padx=6, pady=6)
    for k in ("<Escape>", "<Return>", "<KP_Enter>"):
        w.bind(k, lambda e: w.destroy())
    w.lift()
    w.focus_force()
    w.grab_set()


def bgjob(fn, title):
    wait = tk.Toplevel(root)
    wait.title(title)
    wait.geometry("420x120+120+120")
    tk.Label(wait, text="Please wait...", font=FB).pack(expand=True)
    res = []
    th = threading.Thread(target=lambda: res.append(fn()), daemon=True)
    th.start()

    def poll():
        if th.is_alive():
            root.after(300, poll)
        else:
            wait.destroy()
            show(title, res[0] if res else "done")
    poll()


def apply_bg(title, extra=""):
    def work():
        otc.apply_now(lambda m: None)
        return "Applied.\n" + extra
    bgjob(work, title)


def a_wifi():
    ns = [n for n in otc.nics() if n["wifi"]]
    if not ns:
        messagebox.showinfo("Wi-Fi", "No Wi-Fi card found on this device.\nRaspberry Pi 4/5 have one built in; on a PC/VM plug in a USB Wi-Fi adapter.")
        return
    ifn = ns[0]["name"]
    cfg = otc.load_json(os.path.join(otc.STATE, "slot.json"))
    cc = str(cfg.get("wifi_country") or "").upper()
    if not re.match(r"^[A-Z]{2}$", cc):
        x = simpledialog.askstring("Wi-Fi country", "Two-letter country code (e.g. IN, US, GB, DE):", parent=root)
        if not x or not re.match(r"^[A-Za-z]{2}$", x):
            return
        cc = x.upper()
        otc.slot_update(wifi_country=cc)
    ssid = simpledialog.askstring("Wi-Fi", "Name of the Wi-Fi network (SSID):", parent=root)
    if not ssid:
        return
    psk = simpledialog.askstring("Wi-Fi", "Password for %s (8-63 characters, empty = open network):" % ssid, show="*", parent=root)
    if psk is None:
        return
    if psk and not (8 <= len(psk) <= 63 or re.match(r"^[0-9A-Fa-f]{64}$", psk)):
        messagebox.showerror("Wi-Fi", "The password must be 8 to 63 characters.")
        return
    otc.slot_update(wifi_ssid=ssid, wifi_psk=psk, wifi_hidden=False, mgmt="wifi")
    pp = os.path.join(otc.STATE, "ports.json")
    if otc.load_json(pp).get("manual"):
        os.remove(pp)

    def work():
        otc.cmd(["rfkill", "unblock", "wifi"])
        otc.cmd(["iw", "reg", "set", cc])
        otc.apply_now(lambda m: None)
        for _ in range(25):
            a = otc.ips().get(ifn)
            if a:
                return "Connected to %s\nManagement address: %s\nWeb page: https://%s:8080" % (ssid, a[0], a[0])
            time.sleep(1)
        return "No address yet from %s.\nWrong password, weak signal, or the router blocks new devices." % ssid
    bgjob(work, "Wi-Fi")


def a_network():
    if messagebox.askyesno("Network address", "Use automatic address (DHCP)?\n\nYes = DHCP     No = fixed IP address", parent=root):
        otc.slot_update(mode="dhcp", ip_cidr="", gateway="", dns="")
    else:
        cfg = otc.load_json(os.path.join(otc.STATE, "slot.json"))
        a = simpledialog.askstring("Fixed IP", "IP address with prefix, e.g. 192.168.1.50/24", initialvalue=cfg.get("ip_cidr", ""), parent=root)
        if not a or not re.match(r"^\d{1,3}(\.\d{1,3}){3}/\d{1,2}$", a):
            return
        g = simpledialog.askstring("Fixed IP", "Gateway (router), e.g. 192.168.1.1", initialvalue=cfg.get("gateway", ""), parent=root)
        if not g or not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", g):
            return
        d = simpledialog.askstring("Fixed IP", "DNS server(s), comma separated", initialvalue=cfg.get("dns", "") or g, parent=root)
        if d is None:
            return
        otc.slot_update(mode="static", ip_cidr=a, gateway=g, dns=d)
    bgjob(lambda: (otc.apply_now(lambda m: None), "Applied.")[1], "Network address")


def a_ports():
    ns = otc.nics()
    if not ns:
        messagebox.showinfo("Ports", "No network port found.")
        return
    mg, sp = otc.roles()
    names = [n["name"] for n in ns]
    ans = simpledialog.askstring("Management port", "Management port (all other wired ports = SPAN / capture).\nAvailable: %s\nType 'auto' to choose automatically." % ", ".join(names),
                                 initialvalue=mg, parent=root)
    if not ans:
        return
    if ans.strip().lower() == "auto":
        try:
            os.remove(os.path.join(otc.STATE, "ports.json"))
        except OSError:
            pass
    elif ans not in names:
        messagebox.showerror("Ports", "%r is not one of: %s" % (ans, ", ".join(names)))
        return
    else:
        span = [n["name"] for n in ns if n["name"] != ans and not n["wifi"]]
        otc.save_json(os.path.join(otc.STATE, "ports.json"), {"mgmt": ans, "span": span, "manual": True})
    apply_bg("Ports")


def a_central():
    cfg = otc.load_json(os.path.join(otc.STATE, "slot.json"))
    url = simpledialog.askstring("Central server", "Web address of central, e.g. https://central.example.com", initialvalue=cfg.get("central", ""), parent=root)
    if url is None:
        return
    if url and "://" not in url:
        url = "https://" + url
    tok = simpledialog.askstring("Central server", "Site token (from central: Sites tab). Empty = keep the current one", show="*", parent=root)
    if tok is None:
        return
    site = simpledialog.askstring("Central server", "Site name", initialvalue=cfg.get("site", "") or os.uname()[1], parent=root)
    if site is None:
        return
    otc.slot_update(site=site, central=url.rstrip("/"), token=tok or cfg.get("token", ""))
    apply_bg("Central server")
    otc.check_central(True)


def a_test():
    def work():
        otc.check_central(True)
        time.sleep(7)
        mg, _ = otc.roles()
        a = (otc.ips().get(mg) or [""])[0]
        return "Management port %s: %s\nCentral: %s" % (mg or "none", a or "no address", otc._central["txt"])
    bgjob(work, "Test connectivity")


def a_ping():
    host = simpledialog.askstring("Ping", "Host name or IP to ping", initialvalue="8.8.8.8", parent=root)
    if not host or not re.match(r"^[A-Za-z0-9._:-]+$", host):
        return
    bgjob(lambda: otc.cmd(["ping", "-c", "4", "-W", "2", host], 15) or "no output", "Ping " + host)


def a_pw():
    messagebox.showinfo("Web password", "Web page password: %s\n\nThe web page also accepts your central console user name and password." % (otc.env().get("WEBPW") or "(not created yet)"))


def a_restart():
    if not otc.DRY:
        os.system("systemctl restart otsense-sensor.service")
    messagebox.showinfo("Sensor", "The sensor service is restarting (about 20 seconds).")


def a_log():
    bgjob(lambda: otc.cmd(["journalctl", "-u", "otsense-sensor", "-n", "80", "--no-pager", "-o", "cat"], 10) or "no log yet", "Sensor log")


def a_text():
    if messagebox.askyesno("Text screen", "Switch to the text screen? (it also works without graphics)"):
        root.destroy()
        sys.exit(3)


def a_reboot():
    if messagebox.askyesno("Restart", "Restart this sensor now?"):
        otc.cmd(["systemctl", "reboot"])


def a_off():
    if messagebox.askyesno("Power off", "Power off this sensor now?"):
        otc.cmd(["systemctl", "poweroff"])


BUTTONS = [("Network address", a_network), ("Ports (mgmt / SPAN)", a_ports), ("Central server", a_central), ("Test connectivity", a_test),
           ("Wi-Fi network", a_wifi), ("Ping", a_ping), ("Web password", a_pw), ("Restart sensor", a_restart),
           ("Show log", a_log), ("Text screen", a_text), ("Restart", a_reboot), ("Power off", a_off)]
fr = tk.Frame(root, bg=BG)
fr.pack(fill="x", padx=14, pady=8)
for i, (name, fn) in enumerate(BUTTONS):
    b = tk.Button(fr, text=name, command=fn, font=FB, bg="#2d4a66", fg="white", activebackground="#3f6a94", activeforeground="white", relief="raised", bd=3, height=1, pady=6)
    b.grid(row=i // 4, column=i % 4, sticky="nsew", padx=4, pady=4)
    b.bind("<Return>", lambda e: e.widget.invoke())
for c in range(4):
    fr.columnconfigure(c, weight=1)
refresh()
root.mainloop()
