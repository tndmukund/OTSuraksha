#!/usr/bin/env python3
"""OT Sense OS - graphical screen (buttons and windows, full screen). Same look and same buttons as the sensor ISO / OVA screen.
Started by otsense-screen.sh on tty1. It reuses the data and settings code of otsense-console.py (the text screen), so both always agree.
If the graphics cannot start, the text screen takes over by itself."""
import importlib.util, os, re, shutil, subprocess, sys, threading, time
import tkinter as tk
from tkinter import messagebox, scrolledtext

D = os.environ.get("D", "/opt/otsense")
spec = importlib.util.spec_from_file_location("otc", os.path.join(D, "otsense-console.py"))
otc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(otc)

BG, PANEL, FG, CYAN, YEL = "#101820", "#1b2733", "#e8eef4", "#5ac8fa", "#ffd24a"
F, FB, FM = ("DejaVu Sans", 12), ("DejaVu Sans", 12, "bold"), ("DejaVu Sans Mono", 11)

root = tk.Tk()
root.title("OT Sense")
root.configure(bg=BG)
root.attributes("-fullscreen", True)
root.config(cursor="arrow")


# ---- clipboard: copy / paste between this console and the host (needs open-vm-tools-desktop or spice-vdagent in the image) ----
import shutil, subprocess
for _cmd in (["vmtoolsd", "-n", "vmusr"], ["spice-vdagent"]):
    if shutil.which(_cmd[0]):
        try:
            subprocess.Popen(_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


def clip_set(text):
    root.clipboard_clear()
    root.clipboard_append(text)
    root.update()


def clip_get():
    for fn in (lambda: root.clipboard_get(), lambda: root.selection_get(selection="PRIMARY")):
        try:
            t = fn()
            if t:
                return t
        except tk.TclError:
            pass
    for cmd in (["xclip", "-o", "-selection", "clipboard"], ["xsel", "-b", "-o"]):
        if shutil.which(cmd[0]):
            try:
                t = subprocess.run(cmd, capture_output=True, text=True, timeout=3).stdout
                if t:
                    return t
            except Exception:
                pass
    return ""


def entry_menu(e, x, y):
    m = tk.Menu(root, tearoff=0)
    m.add_command(label="Copy", command=lambda: clip_set(e.selection_get() if e.selection_present() else e.get()))
    if str(e.cget("state")) == "normal":
        m.add_command(label="Paste", command=lambda: (e.selection_present() and e.delete("sel.first", "sel.last"), e.insert("insert", clip_get().strip())))
    m.add_command(label="Select all", command=lambda: (e.focus_set(), e.selection_range(0, "end")))
    m.tk_popup(x, y)


root.bind_class("Entry", "<Button-3>", lambda ev: entry_menu(ev.widget, ev.x_root, ev.y_root))


def pick(title, prompt, options, current=""):
    """Drop-down list (a real combo box) instead of typing a name. Returns the chosen entry or None on cancel."""
    from tkinter import ttk
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("+40+40")
    tk.Label(w, text=prompt, bg=PANEL, fg=FG, font=F, justify="left", anchor="w", wraplength=820).pack(fill="x", padx=12, pady=(12, 6))
    var = tk.StringVar(value=current if current in options else (options[0] if options else ""))
    root.option_add("*TCombobox*Listbox.font", FB)
    cb = ttk.Combobox(w, textvariable=var, values=list(options), state="readonly", font=FB, width=40)
    cb.pack(fill="x", padx=12, pady=6)
    res = [None]

    def ok(_e=None):
        res[0] = var.get()
        w.destroy()
    bf = tk.Frame(w, bg=PANEL)
    bf.pack(fill="x", padx=12, pady=10)
    for txt, cmd in (("OK", ok), ("Cancel", w.destroy)):
        tk.Button(bf, text=txt, command=cmd, font=FB, bg="#2d4a66", fg="white", width=9, pady=4).pack(side="left", padx=4)
    w.bind("<Return>", ok)
    w.bind("<Escape>", lambda _e: w.destroy())
    w.lift()
    cb.focus_force()
    try:
        w.wait_visibility()
        w.grab_set()
    except tk.TclError:
        pass
    w.wait_window()
    return res[0]


def open_web(url):
    """Open the sensor's own web page on this screen, if the image has a browser; otherwise say how to open it from another computer."""
    for b in ("firefox-esr", "firefox", "chromium", "chromium-browser", "epiphany-browser", "falkon"):
        p = shutil.which(b)
        if not p:
            continue
        if "chrom" in b:
            args = [p, "--no-sandbox", "--kiosk", "--ignore-certificate-errors", "--user-data-dir=/tmp/otsense-browser", url]
        elif "firefox" in b:
            args = [p, "--kiosk", url]
        else:
            args = [p, url]
        try:
            subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            messagebox.showinfo("Web page", "The sensor web page is opening here.\n\nIf it shows a security warning, choose Advanced > Continue (the sensor uses its own certificate).\nPress Ctrl+Q to close the browser and come back to this screen.")
            return
        except Exception:
            continue
    messagebox.showinfo("Web page", "This image has no web browser on its own screen.\n\nOpen this address on your laptop:\n%s\n\n(Use Copy URL, then paste it into your browser.)" % url)


def ask(title, prompt, initial="", secret=False):
    """Text box with Paste / Clear buttons (the stock Tk box has no way to paste from the host). Returns None on cancel."""
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("+40+40")
    tk.Label(w, text=prompt, bg=PANEL, fg=FG, font=F, justify="left", anchor="w", wraplength=820).pack(fill="x", padx=12, pady=(12, 6))
    var = tk.StringVar(value=initial or "")
    e = tk.Entry(w, textvariable=var, font=FM, width=78, show="*" if secret else "")
    e.pack(fill="x", padx=12, pady=4)
    res = [None]

    def ok(_e=None):
        res[0] = var.get() if secret else var.get().strip()
        w.destroy()

    def paste():
        t = clip_get().strip()
        if t:
            if e.selection_present():
                e.delete("sel.first", "sel.last")
            e.insert("insert", t)
        e.focus_set()
    bf = tk.Frame(w, bg=PANEL)
    bf.pack(fill="x", padx=12, pady=10)
    for txt, cmd in (("Paste", paste), ("Clear", lambda: (var.set(""), e.focus_set())), ("OK", ok), ("Cancel", w.destroy)):
        tk.Button(bf, text=txt, command=cmd, font=FB, bg="#2d4a66", fg="white", width=9, pady=4).pack(side="left", padx=4)
    w.bind("<Return>", ok)
    w.bind("<KP_Enter>", ok)
    w.bind("<Escape>", lambda _e: w.destroy())
    w.lift()
    e.focus_force()
    e.icursor("end")
    try:
        w.wait_visibility()
        w.grab_set()
    except tk.TclError:
        pass
    w.wait_window()
    return res[0]



def pick(title, prompt, options, current=""):
    """Drop-down list (a real combo box) instead of typing a name. Returns the chosen entry or None on cancel."""
    from tkinter import ttk
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("+40+40")
    tk.Label(w, text=prompt, bg=PANEL, fg=FG, font=F, justify="left", anchor="w", wraplength=820).pack(fill="x", padx=12, pady=(12, 6))
    var = tk.StringVar(value=current if current in options else (options[0] if options else ""))
    root.option_add("*TCombobox*Listbox.font", FB)
    cb = ttk.Combobox(w, textvariable=var, values=list(options), state="readonly", font=FB, width=40)
    cb.pack(fill="x", padx=12, pady=6)
    res = [None]

    def ok(_e=None):
        res[0] = var.get()
        w.destroy()
    bf = tk.Frame(w, bg=PANEL)
    bf.pack(fill="x", padx=12, pady=10)
    for txt, cmd in (("OK", ok), ("Cancel", w.destroy)):
        tk.Button(bf, text=txt, command=cmd, font=FB, bg="#2d4a66", fg="white", width=9, pady=4).pack(side="left", padx=4)
    w.bind("<Return>", ok)
    w.bind("<Escape>", lambda _e: w.destroy())
    w.lift()
    cb.focus_force()
    try:
        w.wait_visibility()
        w.grab_set()
    except tk.TclError:
        pass
    w.wait_window()
    return res[0]


def open_web(url):
    """Open the sensor's own web page on this screen, if the image has a browser; otherwise say how to open it from another computer."""
    for b in ("firefox-esr", "firefox", "chromium", "chromium-browser", "epiphany-browser", "falkon"):
        p = shutil.which(b)
        if not p:
            continue
        if "chrom" in b:
            args = [p, "--no-sandbox", "--kiosk", "--ignore-certificate-errors", "--user-data-dir=/tmp/otsense-browser", url]
        elif "firefox" in b:
            args = [p, "--kiosk", url]
        else:
            args = [p, url]
        try:
            subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            messagebox.showinfo("Web page", "The sensor web page is opening here.\n\nIf it shows a security warning, choose Advanced > Continue (the sensor uses its own certificate).\nPress Ctrl+Q to close the browser and come back to this screen.")
            return
        except Exception:
            continue
    messagebox.showinfo("Web page", "This image has no web browser on its own screen.\n\nOpen this address on your laptop:\n%s\n\n(Use Copy URL, then paste it into your browser.)" % url)



def panel(title):
    f = tk.LabelFrame(root, text=" %s " % title, bg=PANEL, fg=CYAN, font=FB, bd=2, labelanchor="nw")
    f.pack(fill="x", padx=14, pady=5)
    lb = tk.Label(f, bg=PANEL, fg=FG, font=FM, justify="left", anchor="w")
    lb.pack(fill="x", padx=8, pady=4)
    return lb


hdr = tk.Label(root, text="", bg=BG, fg="#ff8cf0", font=("DejaVu Sans", 16, "bold"), anchor="w")
hdr.pack(fill="x", padx=14, pady=(10, 2))
lbl_if, lbl_sv, lbl_sr = panel("Interfaces"), panel("Services"), panel("Site  (settings from central)")
big = tk.Label(root, text="", bg=BG, fg=YEL, font=("DejaVu Sans", 15, "bold"), anchor="w")
big.pack(fill="x", padx=14, pady=4)
cp = tk.Frame(root, bg=BG)
ent_url = tk.Entry(cp, font=("DejaVu Sans Mono", 13, "bold"), width=28, state="readonly", readonlybackground=PANEL, fg=YEL, bd=2)
ent_pw = tk.Entry(cp, font=("DejaVu Sans Mono", 13, "bold"), width=16, state="readonly", readonlybackground=PANEL, fg=YEL, bd=2)
ent_url.pack(side="left", padx=(0, 4))
tk.Button(cp, text="Copy URL", font=FB, bg="#2d4a66", fg="white", command=lambda: clip_set(ent_url.get())).pack(side="left", padx=4)
tk.Label(cp, text="password:", bg=BG, fg=YEL, font=("DejaVu Sans", 13, "bold")).pack(side="left", padx=(14, 4))
ent_pw.pack(side="left", padx=4)
tk.Button(cp, text="Copy password", font=FB, bg="#2d4a66", fg="white", command=lambda: clip_set(ent_pw.get())).pack(side="left", padx=4)
ntp_cache = [0.0, ""]


def refresh():
    try:
        e, cfg = otc.env(), otc.load_json(os.path.join(otc.STATE, "slot.json"))
        mg, sp = otc.roles()
        a = otc.ips()
        site = e.get("SITE") or cfg.get("site") or ""
        hdr.config(text="OT Sense Appliance     Site: %s     %s" % (site or "not set", time.strftime("%a %d %b %Y %H:%M:%S")))
        try:
            ns = otc.nics()
        except Exception:
            ns = []
        rows = []
        for n in ns[:8]:
            r = "MGMT" if n["name"] == mg else "SPAN" if n["name"] in sp else "-"
            up = otc.rd("%s/%s/carrier" % (otc.SYS, n["name"])) == "1"
            ip = (a.get(n["name"]) or [""])[0]
            tail = ("ip %s" % ip) if r == "MGMT" and ip else "waiting for an address..." if r == "MGMT" else "capture, no IP   rx packets %s" % otc.rx(n["name"]) if r == "SPAN" else ""
            rows.append("[ %-7s ] %-5s %-5s %-8s %s" % (n["name"], r, "UP" if up else "DOWN", "Wi-Fi" if n["wifi"] else "", tail))
        lbl_if.config(text="\n".join(rows) or "No network port found - add a network adapter.")
        mip = (a.get(mg) or [""])[0]
        url = "https://%s:8080" % mip if mip else "waiting for an address"
        otc.check_central()
        active = (otc.cmd(["systemctl", "is-active", "otsense-sensor.service"]) or "?").strip()
        lbl_sv.config(text="Sensor : %s\nWeb page : %s\nCentral : %s   (%s)" % ("Active" if active == "active" else "NOT running (%s) - see Show log" % active, url,
                      cfg.get("central") or e.get("CENTRAL") or "not set - press 'Central server'", otc._central["txt"]))
        now = time.time()
        if now - ntp_cache[0] > 10:
            ntp_cache[0] = now
            ntp_cache[1] = otc.cmd(["timedatectl", "show", "-p", "NTPSynchronized", "--value"]).strip()
        lbl_sr.config(text="Site name   : %s\nCentral     : %s\nSensor name : %s\nIP address  : %s %s\nTime (NTP)  : synchronised: %s" % (
            site or "not set", cfg.get("central") or e.get("CENTRAL") or "not set", e.get("HOST") or os.uname()[1],
            "DHCP" if (cfg.get("mode") or "dhcp") != "static" else "fixed", mip or "waiting...", {"yes": "yes", "no": "no"}.get(ntp_cache[1], "?")))
        if mip:
            big.config(text="Open")
            for ent, val in ((ent_url, url), (ent_pw, e.get("WEBPW", "..."))):
                if ent.get() != val:
                    ent.config(state="normal")
                    ent.delete(0, "end")
                    ent.insert(0, val)
                    ent.config(state="readonly")
            if not cp.winfo_ismapped():
                cp.pack(fill="x", padx=14, pady=(0, 4), after=big)
        else:
            big.config(text="Waiting for an IP address on the management port...")
            cp.pack_forget()
    except Exception as ex:
        big.config(text="screen error: %s" % ex)
    root.after(2000, refresh)


def show(title, text):
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("720x330+30+30")
    tk.Button(w, text="Close  (Esc)", font=FB, bg="#2d4a66", fg="white", height=2, command=w.destroy).pack(side="bottom", fill="x", padx=6, pady=6)
    t = scrolledtext.ScrolledText(w, bg="black", fg=FG, font=FM)
    t.insert("1.0", text)
    t.config(state="disabled")
    t.pack(side="top", fill="both", expand=True, padx=6, pady=6)
    for k in ("<Escape>", "<Return>", "<KP_Enter>"):
        w.bind(k, lambda e: w.destroy())
    w.lift()
    w.focus_force()
    w.grab_set()


def bgjob(fn, title):
    wait = tk.Toplevel(root)
    wait.title(title)
    wait.geometry("420x120+120+120")
    tk.Label(wait, text="Please wait...", font=FB).pack(expand=True)
    res = []
    th = threading.Thread(target=lambda: res.append(fn()), daemon=True)
    th.start()

    def poll():
        if th.is_alive():
            root.after(300, poll)
        else:
            wait.destroy()
            show(title, res[0] if res else "done")
    poll()


def apply_bg(title, extra=""):
    def work():
        otc.apply_now(lambda m: None)
        return "Applied.\n" + extra
    bgjob(work, title)


def a_wifi():
    ns = [n for n in otc.nics() if n["wifi"]]
    if not ns:
        messagebox.showinfo("Wi-Fi", "No Wi-Fi card found on this device.\nRaspberry Pi 4/5 have one built in; on a PC/VM plug in a USB Wi-Fi adapter.")
        return
    ifn = ns[0]["name"]
    cfg = otc.load_json(os.path.join(otc.STATE, "slot.json"))
    cc = str(cfg.get("wifi_country") or "").upper()
    if not re.match(r"^[A-Z]{2}$", cc):
        x = ask("Wi-Fi country", "Two-letter country code (e.g. IN, US, GB, DE):")
        if not x or not re.match(r"^[A-Za-z]{2}$", x):
            return
        cc = x.upper()
        otc.slot_update(wifi_country=cc)
    ssid = ask("Wi-Fi", "Name of the Wi-Fi network (SSID):")
    if not ssid:
        return
    psk = ask("Wi-Fi", "Password for %s (8-63 characters, empty = open network):" % ssid, secret=True)
    if psk is None:
        return
    if psk and not (8 <= len(psk) <= 63 or re.match(r"^[0-9A-Fa-f]{64}$", psk)):
        messagebox.showerror("Wi-Fi", "The password must be 8 to 63 characters.")
        return
    otc.slot_update(wifi_ssid=ssid, wifi_psk=psk, wifi_hidden=False, mgmt="wifi")
    pp = os.path.join(otc.STATE, "ports.json")
    if otc.load_json(pp).get("manual"):
        os.remove(pp)

    def work():
        otc.cmd(["rfkill", "unblock", "wifi"])
        otc.cmd(["iw", "reg", "set", cc])
        otc.apply_now(lambda m: None)
        for _ in range(25):
            a = otc.ips().get(ifn)
            if a:
                return "Connected to %s\nManagement address: %s\nWeb page: https://%s:8080" % (ssid, a[0], a[0])
            time.sleep(1)
        return "No address yet from %s.\nWrong password, weak signal, or the router blocks new devices." % ssid
    bgjob(work, "Wi-Fi")


def a_network():
    if messagebox.askyesno("Network address", "Use automatic address (DHCP)?\n\nYes = DHCP     No = fixed IP address", parent=root):
        otc.slot_update(mode="dhcp", ip_cidr="", gateway="", dns="")
    else:
        cfg = otc.load_json(os.path.join(otc.STATE, "slot.json"))
        a = ask("Fixed IP", "IP address with prefix, e.g. 192.168.1.50/24", cfg.get("ip_cidr", ""))
        if not a or not re.match(r"^\d{1,3}(\.\d{1,3}){3}/\d{1,2}$", a):
            return
        g = ask("Fixed IP", "Gateway (router), e.g. 192.168.1.1", cfg.get("gateway", ""))
        if not g or not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", g):
            return
        d = ask("Fixed IP", "DNS server(s), comma separated", cfg.get("dns", "") or g)
        if d is None:
            return
        otc.slot_update(mode="static", ip_cidr=a, gateway=g, dns=d)
    bgjob(lambda: (otc.apply_now(lambda m: None), "Applied.")[1], "Network address")


def a_ports():
    ns = otc.nics()
    if not ns:
        messagebox.showinfo("Ports", "No network port found.")
        return
    mg, sp = otc.roles()
    names = [n["name"] for n in ns]
    AUTO = "Automatic (let the sensor choose)"
    ans = pick("Management port", "Choose the MANAGEMENT port (this one gets the IP address and talks to central).\nAll the other wired ports become SPAN / capture ports.", names + [AUTO], mg if mg in names else AUTO)
    if not ans:
        return
    if ans == AUTO:
        ans = "auto"
    if ans.strip().lower() == "auto":
        try:
            os.remove(os.path.join(otc.STATE, "ports.json"))
        except OSError:
            pass
    elif ans not in names:
        messagebox.showerror("Ports", "%r is not one of: %s" % (ans, ", ".join(names)))
        return
    else:
        span = [n["name"] for n in ns if n["name"] != ans and not n["wifi"]]
        otc.save_json(os.path.join(otc.STATE, "ports.json"), {"mgmt": ans, "span": span, "manual": True})
    apply_bg("Ports")


def a_central():
    cfg = otc.load_json(os.path.join(otc.STATE, "slot.json"))
    url = ask("Central server", "Web address of central. Paste the sensor address from central (Sites tab), e.g. https://central.example.com/o/organisation/site/sensor", cfg.get("central", ""))
    if url is None:
        return
    if url and "://" not in url:
        url = "https://" + url
    tok = ask("Central server", "Site token (copy it from central: Sites tab, then press Paste). Empty = keep the current one", secret=True)
    if tok is None:
        return
    site = ask("Central server", "Site name", cfg.get("site", "") or os.uname()[1])
    if site is None:
        return
    otc.slot_update(site=site, central=url.rstrip("/"), token=tok or cfg.get("token", ""))
    apply_bg("Central server")
    otc.check_central(True)


def a_test():
    def work():
        otc.check_central(True)
        time.sleep(7)
        mg, _ = otc.roles()
        a = (otc.ips().get(mg) or [""])[0]
        return "Management port %s: %s\nCentral: %s" % (mg or "none", a or "no address", otc._central["txt"])
    bgjob(work, "Test connectivity")


def a_ping():
    host = ask("Ping", "Host name or IP to ping", "8.8.8.8")
    if not host or not re.match(r"^[A-Za-z0-9._:-]+$", host):
        return
    bgjob(lambda: otc.cmd(["ping", "-c", "4", "-W", "2", host], 15) or "no output", "Ping " + host)


def a_pw():
    messagebox.showinfo("Web password", "Web page password: %s\n\nThe web page also accepts your central console user name and password." % (otc.env().get("WEBPW") or "(not created yet)"))


def a_restart():
    if not otc.DRY:
        os.system("systemctl restart otsense-sensor.service")
    messagebox.showinfo("Sensor", "The sensor service is restarting (about 20 seconds).")


def a_log():
    bgjob(lambda: otc.cmd(["journalctl", "-u", "otsense-sensor", "-n", "80", "--no-pager", "-o", "cat"], 10) or "no log yet", "Sensor log")


def a_web():
    open_web(ent_url.get() or "https://localhost:8080")


def a_text():
    if messagebox.askyesno("Text screen", "Switch to the text screen? (it also works without graphics)"):
        root.destroy()
        sys.exit(3)


def a_reboot():
    if messagebox.askyesno("Restart", "Restart this sensor now?"):
        otc.cmd(["systemctl", "reboot"])


def a_off():
    if messagebox.askyesno("Power off", "Power off this sensor now?"):
        otc.cmd(["systemctl", "poweroff"])


BUTTONS = [("Network address", a_network), ("Ports (mgmt / SPAN)", a_ports), ("Central server", a_central), ("Test connectivity", a_test),
           ("Wi-Fi network", a_wifi), ("Ping", a_ping), ("Web password", a_pw), ("Restart sensor", a_restart),
           ("Show log", a_log), ("Open web page", a_web), ("Text screen", a_text), ("Restart", a_reboot), ("Power off", a_off)]
fr = tk.Frame(root, bg=BG)
fr.pack(fill="x", padx=14, pady=8)
for i, (name, fn) in enumerate(BUTTONS):
    b = tk.Button(fr, text=name, command=fn, font=FB, bg="#2d4a66", fg="white", activebackground="#3f6a94", activeforeground="white", relief="raised", bd=3, height=1, pady=6)
    b.grid(row=i // 4, column=i % 4, sticky="nsew", padx=4, pady=4)
    b.bind("<Return>", lambda e: e.widget.invoke())
for c in range(4):
    fr.columnconfigure(c, weight=1)
refresh()
root.mainloop()
