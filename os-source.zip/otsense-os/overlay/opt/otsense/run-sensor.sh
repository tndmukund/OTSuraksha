#!/bin/bash
# OT Sense OS - starts the sensor (otsense-sensor.service). Reads /run/otsense/env written by otsense-prep.py.
# Test:  DRY=1 ENV=./env STATE=./state ./run-sensor.sh
set -u
DRY="${DRY:-0}"; ENV="${ENV:-/run/otsense/env}"; STATE="${STATE:-/var/lib/otsense}"; D="${D:-/opt/otsense}"
run() { if [ "$DRY" = 1 ]; then echo "+ $*"; else "$@"; fi; }
log() { echo "[otsense] $*"; }
# shellcheck disable=SC1090
. "$ENV" || { log "no $ENV - otsense-prep did not run"; exit 1; }
mkdir -p "$STATE"

# SPAN / capture ports: no IP, no IPv6 chatter, promiscuous, offloads off (so the sensor sees real frames, not merged ones)
for c in $(echo "${CAP:-}" | tr ',' ' '); do
  [ -e "/sys/class/net/$c" ] || [ "$DRY" = 1 ] || { log "capture port $c not present"; continue; }
  run sysctl -qw "net.ipv6.conf.$c.disable_ipv6=1" 2>/dev/null
  run ip addr flush dev "$c"
  run ip link set "$c" up promisc on
  run ethtool -K "$c" gro off lro off gso off tso off 2>/dev/null
done

# Remote-access (SRA) port: own IP / VLAN, used only for the engineer sessions started from central (settings: console screen > Remote access port).
# Runs every time so that a port that was switched off loses its rules again. Writes $RUN/sra.env (OTSENSE_SRA_IP) which the sensor reads.
OTS_STATE="$STATE" OTS_RUN="$(dirname "$ENV")" OTS_DRY="$DRY" python3 "$D/otsense-sra.py" apply || log "remote-access (SRA) port not applied (see message above)"
if [ -f "$(dirname "$ENV")/sra.env" ]; then set -a; . "$(dirname "$ENV")/sra.env"; set +a; fi

ARGS=(appliance --state-dir "$STATE")
if [ "${CONFIGURED:-0}" = 1 ]; then
  CONF=(appliance --state-dir "$STATE" --configure-only --site "$SITE" --central "$CENTRAL" --token "$TOKEN" --cafile "$CAFILE")
  [ -n "${CAP:-}" ] && CONF+=(--iface "$CAP")
  [ -n "${MGMT:-}" ] && CONF+=(--mgmt-iface "$MGMT")
  [ -n "${SCAN:-}" ] && CONF+=(--scan "$SCAN")
  CONF+=(--ui-password "$WEBPW")
  run python3 "$D/otsense.py" "${CONF[@]}" || log "could not write the settings (see message above)"
else
  log "no central address / token yet: use the console screen (C = Central settings) or the web page, Setup"
  # still tell the sensor which ports to use, so the web page shows them
  CONF=(appliance --state-dir "$STATE" --configure-only)
  [ -n "${CAP:-}" ] && CONF+=(--iface "$CAP")
  [ -n "${MGMT:-}" ] && CONF+=(--mgmt-iface "$MGMT")
  run python3 "$D/otsense.py" "${CONF[@]}" --ui-password "$WEBPW" || true
fi
ARGS+=(--ui-password "$WEBPW")
run exec python3 "$D/otsense.py" "${ARGS[@]}"
