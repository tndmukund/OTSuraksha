#!/bin/bash
# Runs INSIDE the image (chroot). Same recipe for the x86 disk (Debian 12) and the Raspberry Pi image (Raspberry Pi OS Lite).
# usage: chroot-setup.sh <amd64|arm64>
set -euo pipefail
ARCH="${1:-amd64}"
export DEBIAN_FRONTEND=noninteractive LC_ALL=C
echo "[setup] packages"
apt-get update -qq
PK="python3 openssl iproute2 ethtool tcpdump network-manager wpasupplicant iw rfkill wireless-regdb ca-certificates systemd-timesyncd kbd console-setup-linux less nano sudo"
if [ "$ARCH" = amd64 ]; then      # bare metal / VM: guest tools and the common Wi-Fi + NIC firmware (Debian "non-free-firmware" is enabled by build-image.sh)
  PK="$PK open-vm-tools qemu-guest-agent firmware-linux-free firmware-misc-nonfree firmware-iwlwifi firmware-realtek firmware-atheros firmware-brcm80211"
fi
# shellcheck disable=SC2086
apt-get install -y -qq --no-install-recommends $PK

echo "[setup] sensor files"
chmod +x /opt/otsense/*.sh /opt/otsense/*.py
[ -f /opt/otsense/otsense.py ] || { echo "otsense.py missing in /opt/otsense"; exit 1; }
python3 -m py_compile /opt/otsense/otsense.py /opt/otsense/otsense-prep.py /opt/otsense/otsense-console.py

echo "[setup] console user, no first-run wizard, no cloud-init"
id user >/dev/null 2>&1 || useradd -m -s /bin/bash -G sudo user
echo "user:$(head -c 12 /dev/urandom | base64 | tr -d '/+=')" | chpasswd      # replaced at first boot (stamped password, or one shown on the screen)
passwd -l root >/dev/null 2>&1 || true
systemctl disable userconfig.service 2>/dev/null || true; systemctl mask userconfig.service 2>/dev/null || true       # Raspberry Pi OS first-run user wizard
rm -f /etc/ssh/sshd_config.d/rename_user.conf
mkdir -p /etc/cloud && touch /etc/cloud/cloud-init.disabled                                                              # newer Raspberry Pi OS uses cloud-init
systemctl disable ssh.service sshd.service 2>/dev/null || true                                                           # no remote shell unless someone enables it
systemctl disable avahi-daemon.service triggerhappy.service bluetooth.service hciuart.service 2>/dev/null || true

echo "[setup] remote desktop service (guacd) for approved browser sessions - optional, never stops the build"
bash /opt/otsense/install-guacd.sh || true
rm -f /opt/otsense/install-guacd.sh
mkdir -p /etc/guacamole; printf '[server]\nbind_host = 127.0.0.1\nbind_port = 4822\n' > /etc/guacamole/guacd.conf
echo "[setup] services"
systemctl enable NetworkManager.service systemd-timesyncd.service otsense-prep.service otsense-sensor.service otsense-console.service
systemctl disable getty@tty1.service 2>/dev/null || true
systemctl mask getty@tty1.service 2>/dev/null || true
systemctl disable wpa_supplicant.service dhcpcd.service 2>/dev/null || true     # NetworkManager runs its own wpa_supplicant; dhcpcd must not touch the SPAN ports
systemctl set-default multi-user.target
# Raspberry Pi has no battery clock: remember the last time across reboots until NTP answers
dpkg -s fake-hwclock >/dev/null 2>&1 || apt-get install -y -qq fake-hwclock || true

echo "[setup] release marker, clean up"
printf 'OT Sense OS 1.0 (%s)\nbuilt %s\n' "$ARCH" "$(date -u +%FT%TZ)" > /etc/otsense-release
apt-get clean; rm -rf /var/lib/apt/lists/* /var/cache/apt/*.bin /tmp/* /var/tmp/* /root/.cache
rm -f /etc/machine-id; touch /etc/machine-id; rm -f /var/lib/dbus/machine-id
rm -f /etc/ssh/ssh_host_*_key* 2>/dev/null || true
find /var/log -type f -exec truncate -s 0 {} \; 2>/dev/null || true
echo "[setup] done"
