#!/bin/bash
# OT Sense sensor - started at every boot by otsense-sensor.service (runs as root, inside the live ISO system).
# 1. brings the network up (first port = management, DHCP or the fixed IP stamped by central; all other ports = SPAN/capture)
# 2. reads the settings stamped into the ISO by central, 3. runs the sensor (same otsense.py as the container).
# The text screen on the VM console is a separate service (otsense-console.service).
# Test:  DRY_RUN=1 NICS="eth0 eth1" SLOT=./slot.bin STATE=/tmp/st RUN=/tmp/rn D=. ./run-sensor.sh
set -u
DRY="${DRY_RUN:-0}"; SLOT="${SLOT:-/run/live/medium/otsense/slot.bin}"; D="${D:-/opt/otsense}"; STATE="${STATE:-/var/lib/otsense}"; RUN="${RUN:-/run/otsense}"; CA="${CA:-/opt/otsense/ca.crt}"
export D STATE RUN
run() { if [ "$DRY" = 1 ]; then echo "+ $*"; else "$@"; fi; }
log() { echo "[otsense] $*"; }
mkdir -p "$STATE" "$RUN"; chmod 700 "$RUN" 2>/dev/null || true
eval "$(python3 "$D/slot-read.py" "$SLOT" "$CA")"
# Hypervisors that cannot hold the stamp inside the disk: central can also stamp a small config CD (label OTCONFIG, part of the OVA, or the separate
# otsense-config ISO of the site). The first CD found that holds a stamped slot is used.
if [ "${CONFIGURED:-0}" != 1 ] && command -v blkid >/dev/null 2>&1 && [ "$DRY" != 1 ]; then
  for LBL in OTCONFIG CIDATA; do
    CFGDEV="$(blkid -L "$LBL" 2>/dev/null || true)"; [ -n "$CFGDEV" ] || continue
    mkdir -p "$RUN/cfgcd"; mount -o ro "$CFGDEV" "$RUN/cfgcd" 2>/dev/null || continue
    for F in otsense/slot.bin slot.bin SLOT.BIN; do
      [ -f "$RUN/cfgcd/$F" ] && eval "$(python3 "$D/slot-read.py" "$RUN/cfgcd/$F" "$CA")" && [ "${CONFIGURED:-0}" = 1 ] && break
    done
    umount "$RUN/cfgcd" 2>/dev/null || true
    [ "${CONFIGURED:-0}" = 1 ] && break
  done
fi
STAMPED="${CONFIGURED:-0}"
# settings typed on the console screen (menu "Central server") win over the stamped ones
# shellcheck disable=SC1090
[ -f "$STATE/override.env" ] && . "$STATE/override.env"
if [ "${CONFIGURED:-0}" != 1 ] && [ -n "${CENTRAL:-}" ] && [ -n "${TOKEN:-}" ]; then CONFIGURED=1; fi

# name of this sensor (DNS name) and the time server of the site, when central stamped them
if [ -n "${SENSOR_HOSTNAME:-}" ] && [ "$DRY" != 1 ]; then
  hostname "${SENSOR_HOSTNAME%%.*}" 2>/dev/null || true; echo "${SENSOR_HOSTNAME%%.*}" > /etc/hostname
  grep -q "$SENSOR_HOSTNAME" /etc/hosts 2>/dev/null || echo "127.0.1.1 $SENSOR_HOSTNAME ${SENSOR_HOSTNAME%%.*}" >> /etc/hosts
fi
if [ -n "${NTP:-}" ] && [ "$DRY" != 1 ]; then
  mkdir -p /etc/systemd/timesyncd.conf.d; printf '[Time]\nNTP=%s\n' "$(echo "$NTP" | tr ',' ' ')" > /etc/systemd/timesyncd.conf.d/otsense.conf
  systemctl restart systemd-timesyncd 2>/dev/null || true
fi
# what the console screen shows as "settings from central"
SITE="${SITE:-}" CENTRAL="${CENTRAL:-}" MODE="${MODE:-dhcp}" IP_CIDR="${IP_CIDR:-}" GATEWAY="${GATEWAY:-}" DNS="${DNS:-}" NTP="${NTP:-}" SENSOR_HOSTNAME="${SENSOR_HOSTNAME:-}" STAMPED="$STAMPED" python3 - "$RUN/site-info.json" <<'PY' || true
import json, os, sys
e = os.environ
d = {"stamped": e.get("STAMPED") == "1", "site": e.get("SITE", ""), "central": e.get("CENTRAL", ""), "mode": e.get("MODE", "dhcp") or "dhcp", "ip_cidr": e.get("IP_CIDR", ""),
     "gateway": e.get("GATEWAY", ""), "dns": e.get("DNS", ""), "ntp": e.get("NTP", ""), "hostname": e.get("SENSOR_HOSTNAME", "")}
os.makedirs(os.path.dirname(sys.argv[1]), exist_ok=True)
open(sys.argv[1], "w").write(json.dumps(d))
PY

# network first: this is what gives the sensor its address (DHCP is started here, nothing else does it in the live system)
MODE="${MODE:-dhcp}" IP_CIDR="${IP_CIDR:-}" GATEWAY="${GATEWAY:-}" DNS="${DNS:-}" python3 "$D/otsense-console.py" --net
eval "$(python3 "$D/otsense-console.py" --ports)"

# web page password: set on the console > the console password stamped by central > random (shown on the console screen)
if [ -s "$STATE/ui-password" ]; then WPW="$(cat "$STATE/ui-password")"
elif [ -n "${CONSOLE_PASSWORD:-}" ]; then WPW="$CONSOLE_PASSWORD"
elif [ -s "$RUN/ui-password" ]; then WPW="$(cat "$RUN/ui-password")"
else WPW="$(python3 -c 'import secrets;print(secrets.token_urlsafe(9))')"
  # OVA: the settings disk is mounted, so keep the generated password (it stays the same after a reboot)
  if [ "$DRY" != 1 ] && mountpoint -q "$STATE"; then ( umask 077; printf '%s' "$WPW" > "$STATE/ui-password" ); fi
fi
( umask 077; printf '%s' "$WPW" > "$RUN/ui-password" )
[ -n "${CONSOLE_PASSWORD:-}" ] && [ "$DRY" != 1 ] && echo "user:$CONSOLE_PASSWORD" | chpasswd

if [ "${CONFIGURED:-0}" != 1 ]; then
  log "This ISO was not stamped by central and no central address was typed on the console. Manual mode: open the web page and use Setup."
  run exec python3 "$D/otsense.py" appliance --state-dir "$STATE" --ui-password "$WPW"
  exit 0
fi
[ "${HAVE_CA:-0}" = 1 ] || run cp /etc/ssl/certs/ca-certificates.crt "$CA"
log "site=${SITE:-} management=${MGMT:-none} capture=${CAP:-none}"
run python3 "$D/otsense.py" appliance --state-dir "$STATE" --configure-only --site "${SITE:-}" --central "$CENTRAL" --token "$TOKEN" --cafile "$CA" \
  ${CAP:+--iface "$CAP"} ${MGMT:+--mgmt-iface "$MGMT"} --ui-password "$WPW"
run exec python3 "$D/otsense.py" appliance --state-dir "$STATE" --ui-password "$WPW"
