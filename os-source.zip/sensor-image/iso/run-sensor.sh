#!/bin/bash
# OT Sense sensor - started at every boot by otsense-sensor.service (runs as root, inside the live ISO system).
# Reads the settings stamped into the ISO by central, sets the network ports, then runs the sensor (same otsense.py as the container).
# Test:  DRY_RUN=1 NICS="eth0 eth1" SLOT=./slot.bin ./run-sensor.sh
set -u
DRY="${DRY_RUN:-0}"; SLOT="${SLOT:-/run/live/medium/otsense/slot.bin}"; D="${D:-/opt/otsense}"; STATE="${STATE:-/var/lib/otsense}"; CA="${CA:-/opt/otsense/ca.crt}"
run() { if [ "$DRY" = 1 ]; then echo "+ $*"; else "$@"; fi; }
log() { echo "[otsense] $*"; }
mkdir -p "$STATE"
# The web page of the sensor is https://<address>:8080 (self-signed certificate, so the browser shows a warning once: choose Advanced > continue).
banner() {   # $1 = address, $2 = web password, $3 = extra line
  [ "$DRY" = 1 ] && { echo "[banner] https://${1:-<no address yet>}:8080 password=${2:-}"; return; }
  printf '\n  OT Sense sensor %s\n  Web page:  https://%s:8080   (warning about the certificate is normal: Advanced > continue)\n  Web login: your central console user name + password, or leave the user name empty and use the setup password: %s\n  %s\n\n' "${SITE:+- site $SITE}" "${1:-<no address yet>}" "${2:-}" "${3:-}" > /etc/issue
  agetty --reload 2>/dev/null || true; [ -w /dev/tty1 ] && printf '\n  >>> OT Sense web page: https://%s:8080   password: %s\n\n' "${1:-<no address yet>}" "${2:-}" > /dev/tty1 2>/dev/null || true
}
myip() { ip -o -4 addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1; }
eval "$(python3 "$D/slot-read.py" "$SLOT" "$CA")"
if [ "${CONFIGURED:-0}" != 1 ]; then
  log "This ISO was not stamped by central (download it from central: Sites > Build a sensor). Starting in manual mode: open the web page and use Setup."
  # network helper: lets the web page change the management IP (with automatic roll-back); there is no systemd path unit in the live image
  [ "$DRY" = 1 ] || python3 "$D/otsense.py" netapply --state-dir "$STATE" --loop >/var/log/otsense-netapply.log 2>&1 &
  WPW="$(python3 -c 'import secrets;print(secrets.token_urlsafe(9))')"
  ( for i in $(seq 1 40); do A="$(myip)"; [ -n "$A" ] && break; sleep 3; done; banner "$A" "$WPW" "Not stamped by central: open the web page and use Setup." ) &
  run exec python3 "$D/otsense.py" appliance --state-dir "$STATE" --ui-password "$WPW"
  exit 0
fi
[ "${HAVE_CA:-0}" = 1 ] || run cp /etc/ssl/certs/ca-certificates.crt "$CA"
[ -n "${CONSOLE_PASSWORD:-}" ] && [ "$DRY" != 1 ] && echo "user:$CONSOLE_PASSWORD" | chpasswd

# network ports: 1st physical port (sorted by name) = management, every other physical port = capture (SPAN, no IP). Roles can be changed on the web page.
if [ -n "${NICS:-}" ]; then LIST="$NICS"; else LIST=""
  for d in /sys/class/net/*; do n="$(basename "$d")"
    case "$n" in lo|docker*|veth*|br-*|virbr*|tun*|tap*|ifb*|bond*|wl*) continue;; esac
    [ -e "$d/device" ] && LIST="$LIST $n"; done; LIST="$(echo "$LIST" | tr ' ' '\n' | sort | tr '\n' ' ')"; fi
set -- $LIST; MGMT="${1:-}"; shift 2>/dev/null || true; CAP="$(echo "$*" | tr ' ' ',')"
log "site=$SITE management=${MGMT:-none} capture=${CAP:-none}"
if [ -n "$MGMT" ]; then
  IF="auto $MGMT\n"
  if [ "$MODE" = static ]; then
    IF="${IF}iface $MGMT inet static\n  address $IP_CIDR\n  gateway $GATEWAY\n"
    if [ "$DRY" = 1 ]; then echo "(resolv.conf: $DNS)"; else : > /etc/resolv.conf; for x in $(echo "$DNS" | tr ',' ' '); do echo "nameserver $x" >> /etc/resolv.conf; done; fi
  else IF="${IF}iface $MGMT inet dhcp\n"; fi
  if [ "$DRY" = 1 ]; then printf "$IF"; else
    printf "$IF" > /etc/network/interfaces.d/otsense; ip addr flush dev "$MGMT" 2>/dev/null; ifup "$MGMT" 2>&1 || log "ifup $MGMT failed"; fi
fi
for c in $(echo "$CAP" | tr ',' ' '); do run ip addr flush dev "$c"; run ip link set "$c" up promisc on; done

# wait (max 60 s) for an address, then show the web page address on the console
IP=""; for i in $(seq 1 30); do IP="$(ip -o -4 addr show dev "${MGMT:-lo}" 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1)"; [ -n "$IP" ] && break; [ "$DRY" = 1 ] && break; sleep 2; done
banner "${IP:-}" "${CONSOLE_PASSWORD:-}" "Console login (troubleshooting): user / ${CONSOLE_PASSWORD:-}"
[ -n "$IP" ] || [ "$DRY" = 1 ] || ( for i in $(seq 1 100); do A="$(myip)"; [ -n "$A" ] && { banner "$A" "${CONSOLE_PASSWORD:-}" "Console login (troubleshooting): user / ${CONSOLE_PASSWORD:-}"; break; }; sleep 5; done ) &

run python3 "$D/otsense.py" appliance --state-dir "$STATE" --configure-only --site "$SITE" --central "$CENTRAL" --token "$TOKEN" --cafile "$CA" \
  ${CAP:+--iface "$CAP"} ${MGMT:+--mgmt-iface "$MGMT"} ${CONSOLE_PASSWORD:+--ui-password "$CONSOLE_PASSWORD"}
[ "$DRY" = 1 ] || python3 "$D/otsense.py" netapply --state-dir "$STATE" --loop >/var/log/otsense-netapply.log 2>&1 &
run exec python3 "$D/otsense.py" appliance --state-dir "$STATE" ${CONSOLE_PASSWORD:+--ui-password "$CONSOLE_PASSWORD"}
