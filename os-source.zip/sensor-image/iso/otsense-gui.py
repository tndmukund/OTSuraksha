#!/usr/bin/env python3
"""OT Sense appliance screen, graphical version (buttons and windows, started full screen by otsense-screen.sh).
Same actions as the text console (otsense-console.py, which it reuses). If the graphics cannot start, the text console takes over."""
import importlib.util, ipaddress, os, re, sys, threading, time
import tkinter as tk
from tkinter import simpledialog, messagebox, scrolledtext

D = os.environ.get("D", "/opt/otsense")
spec = importlib.util.spec_from_file_location("otc", os.path.join(D, "otsense-console.py"))
otc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(otc)

BG, PANEL, FG, GREEN, RED, YEL, CYAN = "#101820", "#1b2733", "#e8eef4", "#4cd964", "#ff5c5c", "#ffd24a", "#5ac8fa"
F = ("DejaVu Sans", 12)
FB = ("DejaVu Sans", 12, "bold")
FM = ("DejaVu Sans Mono", 11)

root = tk.Tk()
root.title("OT Sense")
root.configure(bg=BG)
root.attributes("-fullscreen", True)
root.config(cursor="arrow")
ntp_cache = [0.0, ""]
st = otc.Status()
st.start()


def panel(parent, title):
    f = tk.LabelFrame(parent, text=" %s " % title, bg=PANEL, fg=CYAN, font=FB, bd=2, labelanchor="nw")
    f.pack(fill="x", padx=14, pady=5)
    return f


hdr = tk.Label(root, text="", bg=BG, fg="#ff8cf0", font=("DejaVu Sans", 16, "bold"), anchor="w")
hdr.pack(fill="x", padx=14, pady=(10, 2))
p1, p2, p3 = panel(root, "Interfaces"), panel(root, "Services"), panel(root, "Site  (settings from central)")
lbl_if = tk.Label(p1, bg=PANEL, fg=FG, font=FM, justify="left", anchor="w")
lbl_if.pack(fill="x", padx=8, pady=4)
lbl_sv = tk.Label(p2, bg=PANEL, fg=FG, font=FM, justify="left", anchor="w")
lbl_sv.pack(fill="x", padx=8, pady=4)
lbl_sr = tk.Label(p3, bg=PANEL, fg=FG, font=FM, justify="left", anchor="w")
lbl_sr.pack(fill="x", padx=8, pady=4)
big = tk.Label(root, text="", bg=BG, fg=YEL, font=("DejaVu Sans", 15, "bold"), anchor="w")
big.pack(fill="x", padx=14, pady=4)


def refresh():
    d = st.d
    hdr.config(text="OT Sense Appliance     Site: %s     %s UTC" % (d["site"] or "not stamped", time.strftime("%a %d %b %Y %H:%M:%S", time.gmtime())))
    rows = []
    for p in d["ports"]:
        if p["role"] == "MGMT":
            tail = ("ip %s   gw %s   ping %s" % (p["ip"], d["gw"] or "-", d["ping"] or "-")) if p["ip"] else "waiting for an address..."
        else:
            tail = "capture, no IP   rx packets %s" % p["rx"]
        rows.append("[ %-6s ] %-5s %-5s %s  %s" % (p["n"], p["role"], p["state"].upper(), p.get("mac", ""), tail))
    lbl_if.config(text="\n".join(rows) or "No network port found - add a Network Adapter to the VM.")
    lbl_sv.config(text="Sensor : %s\nWeb page : %s\nCentral : %s" % ("Active" if d["active"] == "active" else "NOT running (%s) - see Show log" % d["active"],
                                                                  otc.web_url(st), d["central"] or "not set - press 'Central server'"))
    si = otc.read_json(os.path.join(otc.RUN, "site-info.json"))
    nowt = time.time()
    if nowt - ntp_cache[0] > 10:
        ntp_cache[0] = nowt
        ntp_cache[1] = otc.sh(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])[1].strip()
    mode = d.get("mode") or si.get("mode") or "dhcp"
    dns = si.get("dns") if (mode == "static" and si.get("dns")) else ", ".join(re.findall(r"^nameserver\s+(\S+)", otc.rd("/etc/resolv.conf"), re.M)[:2])
    ntp = si.get("ntp") or "not set"
    host = os.uname()[1]
    lbl_sr.config(text="Site name   : %s      (%s)\n"
                       "Central     : %s      DNS %s   HTTPS %s\n"
                       "Sensor name : %s\n"
                       "IP address  : %s %s    gateway %s    DNS server %s\n"
                       "Time (NTP)  : %s      synchronised: %s" % (
        d["site"] or "not set", "stamped by central" if si.get("stamped") else "not stamped - set on this screen",
        d["central"] or "not set - press 'Central server'", d["dns"] or "-", d["tcp"] or "-",
        si.get("hostname") or host,
        "DHCP" if mode != "static" else "fixed", d["ip"] or "waiting...", d["gw"] or "-", dns or "-",
        ntp, {"yes": "yes", "no": "no"}.get(ntp_cache[1], "?")))
    big.config(text=("Open  %s   password:  %s" % (otc.web_url(st), d["pw"] or "...")) if d["ip"] else "Waiting for an IP address (DHCP)...")
    root.after(2000, refresh)


def show(title, text):
    # no window manager runs on this screen, so the window has no title bar: the Close button is always visible and Esc / Enter / click also close it
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("720x330+30+30")
    tk.Button(w, text="Close  (Esc)", font=FB, bg="#2d4a66", fg="white", height=2, command=w.destroy).pack(side="bottom", fill="x", padx=6, pady=6)
    t = scrolledtext.ScrolledText(w, bg="black", fg=FG, font=FM)
    t.insert("1.0", text)
    t.config(state="disabled")
    t.pack(side="top", fill="both", expand=True, padx=6, pady=6)
    for k in ("<Escape>", "<Return>", "<KP_Enter>"):
        w.bind(k, lambda e: w.destroy())
    w.lift()
    w.focus_force()
    w.grab_set()


def bg(fn, title):
    """run slow work in a thread, show the result when done"""
    wait = tk.Toplevel(root)
    wait.title(title)
    wait.geometry("420x120+120+120")
    tk.Label(wait, text="Please wait...", font=FB).pack(expand=True)
    res = []
    th = threading.Thread(target=lambda: res.append(fn()), daemon=True)
    th.start()

    def poll():
        if th.is_alive():
            root.after(300, poll)
        else:
            wait.destroy()
            show(title, res[0] if res else "done")
    poll()


def a_network():
    c = otc.load_net()
    if messagebox.askyesno("Network address", "Use automatic address (DHCP)?\n\nYes = DHCP     No = fixed IP address", parent=root):
        c["mode"] = "dhcp"
    else:
        ip = simpledialog.askstring("Fixed IP", "IP address with prefix, e.g. 192.168.1.50/24", initialvalue=c["ip_cidr"], parent=root)
        if not ip:
            return
        try:
            ipaddress.ip_interface(ip)
        except ValueError:
            messagebox.showerror("Not valid", "%r is not valid. Example: 192.168.1.50/24" % ip)
            return
        gw = simpledialog.askstring("Fixed IP", "Gateway (router), empty = none", initialvalue=c["gateway"], parent=root)
        dns = simpledialog.askstring("Fixed IP", "DNS server(s), comma separated", initialvalue=c["dns"] or "8.8.8.8", parent=root)
        c.update(mode="static", ip_cidr=ip, gateway=gw or "", dns=dns or "")
    otc.save_net(c)

    def work():
        out = []
        otc.apply_net(out.append, wait=20)
        return "\n".join(out) + "\n\nThe settings last until the next restart. For a permanent address build the sensor in central (Sites > Build)."
    bg(work, "Network address")


def a_ports():
    p = otc.nics()
    if not p:
        messagebox.showinfo("Ports", "No network port found.")
        return
    cur = otc.mgmt_port()
    ans = simpledialog.askstring("Management port", "Management port (all other ports = SPAN / capture).\nAvailable: %s" % ", ".join(p), initialvalue=cur, parent=root)
    if not ans:
        return
    if ans not in p:
        messagebox.showerror("Ports", "%r is not one of: %s" % (ans, ", ".join(p)))
        return
    c = otc.load_net()
    c["mgmt"] = ans
    otc.save_net(c)

    def work():
        out = []
        otc.apply_net(out.append, wait=20)
        otc.restart_sensor()
        return "\n".join(out) + "\n\nThe sensor is restarting to use the new roles."
    bg(work, "Ports")


def a_central():
    s = otc.read_json(otc.SENSORJ)
    url = simpledialog.askstring("Central server", "Web address of central, e.g. https://central.example.com", initialvalue=s.get("central", ""), parent=root)
    if url is None:
        return
    if url and "://" not in url:
        url = "https://" + url
    tok = simpledialog.askstring("Central server", "Site token (copy it from central: Sites tab)", initialvalue=s.get("token", ""), parent=root)
    if tok is None:
        return
    site = simpledialog.askstring("Central server", "Site name", initialvalue=s.get("site", "") or os.uname()[1], parent=root)
    if site is None:
        return
    otc.write_override(site, url, tok)
    otc.restart_sensor()
    messagebox.showinfo("Central server", "Saved. The sensor is restarting and will connect to\n%s" % url)


def a_test():
    def work():
        st.collect()
        d, out = st.d, []

        def line(ok, t):
            out.append("[ %s ] %s" % ({True: " OK ", False: "FAIL", None: " -- "}[ok], t))
        line(bool(d["ip"]), "Management port %s: %s" % (d["mgmt"] or "none", d["ip"] or "no address (check VM network adapter / DHCP)"))
        if d["ip"] and d["gw"]:
            line(d["ping"] != "no reply", "Gateway %s: %s" % (d["gw"], d["ping"]))
        s = otc.read_json(otc.SENSORJ)
        if not s.get("central"):
            line(None, "Central address not set - press 'Central server'")
        else:
            try:
                sys.path.insert(0, D)
                import otsense
                steps, _m = otsense.test_central(s.get("central", ""), s.get("token", ""), s.get("cafile") or None, bool(s.get("insecure")), s.get("site", ""), timeout=6)
                for label, ok, detail in steps:
                    line(ok, "%s: %s" % (label, detail))
            except Exception as e:
                dns, tcp = otc.quick_central(s["central"])
                line(False, "test could not run: %s" % e)
                line(None, "DNS: %s  %s" % (dns, tcp))
        return "\n".join(out)
    bg(work, "Test connectivity")


def a_ping():
    host = simpledialog.askstring("Ping", "Host name or IP to ping", initialvalue=st.d.get("gw") or "8.8.8.8", parent=root)
    if not host or not re.match(r"^[A-Za-z0-9._:-]+$", host):
        return
    bg(lambda: otc.sh(["ping", "-c", "4", "-W", "2", host], timeout=15)[1] or "no output", "Ping " + host)


def a_pw():
    if messagebox.askyesno("Web password", "Web page: %s\nPassword: %s\n\nSet a new password?" % (otc.web_url(st), st.d.get("pw") or "(not created yet)"), parent=root):
        pw = simpledialog.askstring("New password", "New web password (at least 8 characters)", parent=root)
        if pw and len(pw) >= 8:
            otc.write_private(otc.PWFILE, pw)
            otc.restart_sensor()
            messagebox.showinfo("Password", "Saved. The sensor is restarting.")
        elif pw:
            messagebox.showerror("Password", "Too short - use at least 8 characters.")


def a_restart():
    otc.restart_sensor()
    messagebox.showinfo("Sensor", "The sensor service is restarting (about 20 seconds).")


def a_log():
    bg(lambda: otc.sh(["journalctl", "-u", otc.SERVICE, "-n", "80", "--no-pager", "-o", "cat"], timeout=10)[1] or "no log yet", "Sensor log")


def a_text():
    if messagebox.askyesno("Text screen", "Switch to the text screen? (it also works without graphics)"):
        root.destroy()
        sys.exit(3)


def a_reboot():
    if messagebox.askyesno("Restart", "Restart this sensor now?"):
        otc.sh(["systemctl", "reboot"])


def a_off():
    if messagebox.askyesno("Power off", "Power off this sensor now?"):
        otc.sh(["systemctl", "poweroff"])


BUTTONS = [("Network address", a_network), ("Ports (mgmt / SPAN)", a_ports), ("Central server", a_central), ("Test connectivity", a_test),
           ("Ping", a_ping), ("Web password", a_pw), ("Restart sensor", a_restart), ("Show log", a_log),
           ("Text screen", a_text), ("Restart", a_reboot), ("Power off", a_off)]
fr = tk.Frame(root, bg=BG)
fr.pack(fill="x", padx=14, pady=8)
for i, (name, fn) in enumerate(BUTTONS):
    b = tk.Button(fr, text=name, command=fn, font=FB, bg="#2d4a66", fg="white", activebackground="#3f6a94", activeforeground="white", relief="raised", bd=3, height=1, pady=6)
    b.grid(row=i // 4, column=i % 4, sticky="nsew", padx=4, pady=4)
    b.bind("<Return>", lambda e: e.widget.invoke())
for c in range(4):
    fr.columnconfigure(c, weight=1)
refresh()
root.mainloop()
