#!/usr/bin/env python3
"""OT Sense appliance screen, graphical version (buttons and windows, started full screen by otsense-screen.sh).
Same actions as the text console (otsense-console.py, which it reuses). If the graphics cannot start, the text console takes over."""
import importlib.util, ipaddress, os, re, sys, threading, time
import tkinter as tk
from tkinter import simpledialog, messagebox, scrolledtext

D = os.environ.get("D", "/opt/otsense")
spec = importlib.util.spec_from_file_location("otc", os.path.join(D, "otsense-console.py"))
otc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(otc)

BG, PANEL, FG, GREEN, RED, YEL, CYAN = "#101820", "#1b2733", "#e8eef4", "#4cd964", "#ff5c5c", "#ffd24a", "#5ac8fa"
F = ("DejaVu Sans", 12)
FB = ("DejaVu Sans", 12, "bold")
FM = ("DejaVu Sans Mono", 11)

root = tk.Tk()
root.title("OT Sense")
root.configure(bg=BG)
root.attributes("-fullscreen", True)
root.config(cursor="arrow")
ntp_cache = [0.0, ""]
st = otc.Status()
st.start()


# ---- clipboard: copy / paste between this console and the host (needs open-vm-tools-desktop or spice-vdagent in the image) ----
import shutil, subprocess
for _cmd in (["vmtoolsd", "-n", "vmusr"], ["spice-vdagent"]):
    if shutil.which(_cmd[0]):
        try:
            subprocess.Popen(_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


def clip_set(text):
    root.clipboard_clear()
    root.clipboard_append(text)
    root.update()


def clip_get():
    for fn in (lambda: root.clipboard_get(), lambda: root.selection_get(selection="PRIMARY")):
        try:
            t = fn()
            if t:
                return t
        except tk.TclError:
            pass
    for cmd in (["xclip", "-o", "-selection", "clipboard"], ["xsel", "-b", "-o"]):
        if shutil.which(cmd[0]):
            try:
                t = subprocess.run(cmd, capture_output=True, text=True, timeout=3).stdout
                if t:
                    return t
            except Exception:
                pass
    return ""


def entry_menu(e, x, y):
    m = tk.Menu(root, tearoff=0)
    m.add_command(label="Copy", command=lambda: clip_set(e.selection_get() if e.selection_present() else e.get()))
    if str(e.cget("state")) == "normal":
        m.add_command(label="Paste", command=lambda: (e.selection_present() and e.delete("sel.first", "sel.last"), e.insert("insert", clip_get().strip())))
    m.add_command(label="Select all", command=lambda: (e.focus_set(), e.selection_range(0, "end")))
    m.tk_popup(x, y)


root.bind_class("Entry", "<Button-3>", lambda ev: entry_menu(ev.widget, ev.x_root, ev.y_root))


def pick(title, prompt, options, current=""):
    """Drop-down list (a real combo box) instead of typing a name. Returns the chosen entry or None on cancel."""
    from tkinter import ttk
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("+40+40")
    tk.Label(w, text=prompt, bg=PANEL, fg=FG, font=F, justify="left", anchor="w", wraplength=820).pack(fill="x", padx=12, pady=(12, 6))
    var = tk.StringVar(value=current if current in options else (options[0] if options else ""))
    root.option_add("*TCombobox*Listbox.font", FB)
    cb = ttk.Combobox(w, textvariable=var, values=list(options), state="readonly", font=FB, width=40)
    cb.pack(fill="x", padx=12, pady=6)
    res = [None]

    def ok(_e=None):
        res[0] = var.get()
        w.destroy()
    bf = tk.Frame(w, bg=PANEL)
    bf.pack(fill="x", padx=12, pady=10)
    for txt, cmd in (("OK", ok), ("Cancel", w.destroy)):
        tk.Button(bf, text=txt, command=cmd, font=FB, bg="#2d4a66", fg="white", width=9, pady=4).pack(side="left", padx=4)
    w.bind("<Return>", ok)
    w.bind("<Escape>", lambda _e: w.destroy())
    w.lift()
    cb.focus_force()
    try:
        w.wait_visibility()
        w.grab_set()
    except tk.TclError:
        pass
    w.wait_window()
    return res[0]


def open_web(url):
    """Open the sensor's own web page on this screen, if the image has a browser; otherwise say how to open it from another computer."""
    for b in ("firefox-esr", "firefox", "chromium", "chromium-browser", "epiphany-browser", "falkon"):
        p = shutil.which(b)
        if not p:
            continue
        if "chrom" in b:
            args = [p, "--no-sandbox", "--kiosk", "--ignore-certificate-errors", "--user-data-dir=/tmp/otsense-browser", url]
        elif "firefox" in b:
            args = [p, "--kiosk", url]
        else:
            args = [p, url]
        try:
            subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            messagebox.showinfo("Web page", "The sensor web page is opening here.\n\nIf it shows a security warning, choose Advanced > Continue (the sensor uses its own certificate).\nPress Ctrl+Q to close the browser and come back to this screen.")
            return
        except Exception:
            continue
    messagebox.showinfo("Web page", "This image has no web browser on its own screen.\n\nOpen this address on your laptop:\n%s\n\n(Use Copy URL, then paste it into your browser.)" % url)


def ask(title, prompt, initial="", secret=False):
    """Text box with Paste / Clear buttons (the stock Tk box has no way to paste from the host). Returns None on cancel."""
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("+40+40")
    tk.Label(w, text=prompt, bg=PANEL, fg=FG, font=F, justify="left", anchor="w", wraplength=820).pack(fill="x", padx=12, pady=(12, 6))
    var = tk.StringVar(value=initial or "")
    e = tk.Entry(w, textvariable=var, font=FM, width=78, show="*" if secret else "")
    e.pack(fill="x", padx=12, pady=4)
    res = [None]

    def ok(_e=None):
        res[0] = var.get() if secret else var.get().strip()
        w.destroy()

    def paste():
        t = clip_get().strip()
        if t:
            if e.selection_present():
                e.delete("sel.first", "sel.last")
            e.insert("insert", t)
        e.focus_set()
    bf = tk.Frame(w, bg=PANEL)
    bf.pack(fill="x", padx=12, pady=10)
    for txt, cmd in (("Paste", paste), ("Clear", lambda: (var.set(""), e.focus_set())), ("OK", ok), ("Cancel", w.destroy)):
        tk.Button(bf, text=txt, command=cmd, font=FB, bg="#2d4a66", fg="white", width=9, pady=4).pack(side="left", padx=4)
    w.bind("<Return>", ok)
    w.bind("<KP_Enter>", ok)
    w.bind("<Escape>", lambda _e: w.destroy())
    w.lift()
    e.focus_force()
    e.icursor("end")
    try:
        w.wait_visibility()
        w.grab_set()
    except tk.TclError:
        pass
    w.wait_window()
    return res[0]


def panel(parent, title):
    f = tk.LabelFrame(parent, text=" %s " % title, bg=PANEL, fg=CYAN, font=FB, bd=2, labelanchor="nw")
    f.pack(fill="x", padx=14, pady=5)
    return f


hdr = tk.Label(root, text="", bg=BG, fg="#ff8cf0", font=("DejaVu Sans", 16, "bold"), anchor="w")
hdr.pack(fill="x", padx=14, pady=(10, 2))
p1, p2, p3 = panel(root, "Interfaces"), panel(root, "Services"), panel(root, "Site  (settings from central)")
lbl_if = tk.Label(p1, bg=PANEL, fg=FG, font=FM, justify="left", anchor="w")
lbl_if.pack(fill="x", padx=8, pady=4)
lbl_sv = tk.Label(p2, bg=PANEL, fg=FG, font=FM, justify="left", anchor="w")
lbl_sv.pack(fill="x", padx=8, pady=4)
lbl_sr = tk.Label(p3, bg=PANEL, fg=FG, font=FM, justify="left", anchor="w")
lbl_sr.pack(fill="x", padx=8, pady=4)
big = tk.Label(root, text="", bg=BG, fg=YEL, font=("DejaVu Sans", 15, "bold"), anchor="w")
big.pack(fill="x", padx=14, pady=4)
cp = tk.Frame(root, bg=BG)
ent_url = tk.Entry(cp, font=("DejaVu Sans Mono", 13, "bold"), width=28, state="readonly", readonlybackground=PANEL, fg=YEL, bd=2)
ent_pw = tk.Entry(cp, font=("DejaVu Sans Mono", 13, "bold"), width=16, state="readonly", readonlybackground=PANEL, fg=YEL, bd=2)
ent_url.pack(side="left", padx=(0, 4))
tk.Button(cp, text="Copy URL", font=FB, bg="#2d4a66", fg="white", command=lambda: clip_set(ent_url.get())).pack(side="left", padx=4)
tk.Label(cp, text="password:", bg=BG, fg=YEL, font=("DejaVu Sans", 13, "bold")).pack(side="left", padx=(14, 4))
ent_pw.pack(side="left", padx=4)
tk.Button(cp, text="Copy password", font=FB, bg="#2d4a66", fg="white", command=lambda: clip_set(ent_pw.get())).pack(side="left", padx=4)


def refresh():
    d = st.d
    hdr.config(text="OT Sense Appliance     Site: %s     %s UTC" % (d["site"] or "not stamped", time.strftime("%a %d %b %Y %H:%M:%S", time.gmtime())))
    rows = []
    for p in d["ports"]:
        if p["role"] == "MGMT":
            tail = ("ip %s   gw %s   ping %s" % (p["ip"], d["gw"] or "-", d["ping"] or "-")) if p["ip"] else "waiting for an address..."
        elif p["role"] == "SRA":
            sv = d.get("sra") or {}
            tail = "remote access  ip %s%s" % (p["ip"] or sv.get("ip_cidr", ""), ("  VLAN %s" % sv.get("vlan")) if sv.get("vlan") else "")
        else:
            tail = "capture, no IP   rx packets %s" % p["rx"]
        rows.append("[ %-6s ] %-5s %-5s %s  %s" % (p["n"], p["role"], p["state"].upper(), p.get("mac", ""), tail))
    lbl_if.config(text="\n".join(rows) or "No network port found - add a Network Adapter to the VM.")
    lbl_sv.config(text="Sensor : %s\nWeb page : %s\nCentral : %s" % ("Active" if d["active"] == "active" else "NOT running (%s) - see Show log" % d["active"],
                                                                  otc.web_url(st), d["central"] or "not set - press 'Central server'"))
    si = otc.read_json(os.path.join(otc.RUN, "site-info.json"))
    nowt = time.time()
    if nowt - ntp_cache[0] > 10:
        ntp_cache[0] = nowt
        ntp_cache[1] = otc.sh(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])[1].strip()
    mode = d.get("mode") or si.get("mode") or "dhcp"
    dns = si.get("dns") if (mode == "static" and si.get("dns")) else ", ".join(re.findall(r"^nameserver\s+(\S+)", otc.rd("/etc/resolv.conf"), re.M)[:2])
    ntp = si.get("ntp") or "not set"
    host = os.uname()[1]
    lbl_sr.config(text="Site name   : %s      (%s)\n"
                       "Central     : %s      DNS %s   HTTPS %s\n"
                       "Sensor name : %s\n"
                       "IP address  : %s %s    gateway %s    DNS server %s\n"
                       "Time (NTP)  : %s      synchronised: %s" % (
        d["site"] or "not set", "stamped by central" if si.get("stamped") else "not stamped - set on this screen",
        d["central"] or "not set - press 'Central server'", d["dns"] or "-", d["tcp"] or "-",
        si.get("hostname") or host,
        "DHCP" if mode != "static" else "fixed", d["ip"] or "waiting...", d["gw"] or "-", dns or "-",
        ntp, {"yes": "yes", "no": "no"}.get(ntp_cache[1], "?")))
    if d["ip"]:
        big.config(text="Open")
        for ent, val in ((ent_url, otc.web_url(st)), (ent_pw, d["pw"] or "...")):
            if ent.get() != val:
                ent.config(state="normal")
                ent.delete(0, "end")
                ent.insert(0, val)
                ent.config(state="readonly")
        if not cp.winfo_ismapped():
            cp.pack(fill="x", padx=14, pady=(0, 4), after=big)
    else:
        big.config(text="Waiting for an IP address (DHCP)...")
        cp.pack_forget()
    root.after(2000, refresh)


def show(title, text):
    # no window manager runs on this screen, so the window has no title bar: the Close button is always visible and Esc / Enter / click also close it
    w = tk.Toplevel(root)
    w.title(title)
    w.configure(bg=PANEL)
    w.geometry("720x330+30+30")
    tk.Button(w, text="Close  (Esc)", font=FB, bg="#2d4a66", fg="white", height=2, command=w.destroy).pack(side="bottom", fill="x", padx=6, pady=6)
    t = scrolledtext.ScrolledText(w, bg="black", fg=FG, font=FM)
    t.insert("1.0", text)
    t.config(state="disabled")
    t.pack(side="top", fill="both", expand=True, padx=6, pady=6)
    for k in ("<Escape>", "<Return>", "<KP_Enter>"):
        w.bind(k, lambda e: w.destroy())
    w.lift()
    w.focus_force()
    w.grab_set()


def bg(fn, title):
    """run slow work in a thread, show the result when done"""
    wait = tk.Toplevel(root)
    wait.title(title)
    wait.geometry("420x120+120+120")
    tk.Label(wait, text="Please wait...", font=FB).pack(expand=True)
    res = []
    th = threading.Thread(target=lambda: res.append(fn()), daemon=True)
    th.start()

    def poll():
        if th.is_alive():
            root.after(300, poll)
        else:
            wait.destroy()
            show(title, res[0] if res else "done")
    poll()


def a_network():
    c = otc.load_net()
    if messagebox.askyesno("Network address", "Use automatic address (DHCP)?\n\nYes = DHCP     No = fixed IP address", parent=root):
        c["mode"] = "dhcp"
    else:
        ip = ask("Fixed IP", "IP address with prefix, e.g. 192.168.1.50/24", c["ip_cidr"])
        if not ip:
            return
        try:
            ipaddress.ip_interface(ip)
        except ValueError:
            messagebox.showerror("Not valid", "%r is not valid. Example: 192.168.1.50/24" % ip)
            return
        gw = ask("Fixed IP", "Gateway (router), empty = none", c["gateway"])
        dns = ask("Fixed IP", "DNS server(s), comma separated", c["dns"] or "8.8.8.8")
        c.update(mode="static", ip_cidr=ip, gateway=gw or "", dns=dns or "")
    otc.save_net(c)

    def work():
        out = []
        otc.apply_net(out.append, wait=20)
        return "\n".join(out) + "\n\nThe settings last until the next restart. For a permanent address build the sensor in central (Sites > Build)."
    bg(work, "Network address")


def a_ports():
    p = otc.nics()
    if not p:
        messagebox.showinfo("Ports", "No network port found.")
        return
    cur = otc.mgmt_port()
    ans = pick("Management port", "Choose the MANAGEMENT port (this one gets the IP address and talks to central).\nAll the other ports become SPAN / capture ports.", p, cur)
    if not ans:
        return
    c = otc.load_net()
    c["mgmt"] = ans
    otc.save_net(c)

    def work():
        out = []
        otc.apply_net(out.append, wait=20)
        otc.restart_sensor()
        return "\n".join(out) + "\n\nThe sensor is restarting to use the new roles."
    bg(work, "Ports")


def a_sra():
    """Remote access (SRA) port: its own port, optional VLAN and fixed IP. Engineer sessions started from central leave through it."""
    m = otc.sra()
    mg = otc.mgmt_port()
    cands = [n for n in otc.nics() if n != mg]
    if not cands:
        messagebox.showinfo("Remote access (SRA)", "No free port.\nThe remote-access port needs its own network port: add one more network adapter to the VM.", parent=root)
        return
    cur = m.load()
    OFF = "Switch the remote-access port OFF"
    ans = pick("Remote access (SRA) port", "Choose the port used ONLY for engineer remote-access sessions from central.\nIt gets its own fixed IP address (and optional VLAN) and never captures traffic.", cands + [OFF], cur.get("port") if cur.get("port") in cands else cands[0])
    if not ans:
        return
    if ans == OFF:
        m.clear_cfg()
    else:
        if ans not in cands:
            messagebox.showerror("Remote access (SRA)", "%r is not one of: %s" % (ans, ", ".join(cands)), parent=root)
            return
        same = cur.get("port") == ans
        v = ask("Remote access (SRA)", "VLAN number for this port (1-4094). Leave empty for no VLAN.", str(cur.get("vlan") or "") if same else "")
        if v is None:
            return
        ip = ask("Remote access (SRA)", "Fixed IP address with prefix, e.g. 10.20.0.5/24", cur.get("ip_cidr", "") if same else "")
        if not ip:
            return
        gw = ask("Remote access (SRA)", "Gateway inside that network. Leave empty if the devices are on the same network.", cur.get("gateway", "") if same else "")
        if gw is None:
            return
        c = {"port": ans, "vlan": int(v) if v.strip().isdigit() else 0, "ip_cidr": ip.strip(), "gateway": gw.strip()}
        ok, why = m.validate(c, m.other_addresses(skip=(ans, m.ifname(c))))
        if not ok:
            messagebox.showerror("Remote access (SRA)", why, parent=root)
            return
        m.save(c)

    def work():
        out = []
        otc.apply_net(out.append, wait=20)
        otc.restart_sensor()
        return "\n".join(out) + "\n\nEngineer sessions from central leave through the remote-access port only.\nIf a target is not reachable through it, the session fails (the management port is never used)."
    bg(work, "Remote access (SRA)")


def a_central():
    s = otc.read_json(otc.SENSORJ)
    url = ask("Central server", "Web address of central. Paste the sensor address from central (Sites tab), e.g. https://central.example.com/o/organisation/site/sensor", s.get("central", ""))
    if url is None:
        return
    if url and "://" not in url:
        url = "https://" + url
    tok = ask("Central server", "Site token (copy it from central: Sites tab, then press Paste)", s.get("token", ""))
    if tok is None:
        return
    site = ask("Central server", "Site name", s.get("site", "") or os.uname()[1])
    if site is None:
        return
    otc.write_override(site, url, tok)
    otc.restart_sensor()
    messagebox.showinfo("Central server", "Saved. The sensor is restarting and will connect to\n%s" % url)


def a_test():
    def work():
        st.collect()
        d, out = st.d, []

        def line(ok, t):
            out.append("[ %s ] %s" % ({True: " OK ", False: "FAIL", None: " -- "}[ok], t))
        line(bool(d["ip"]), "Management port %s: %s" % (d["mgmt"] or "none", d["ip"] or "no address (check VM network adapter / DHCP)"))
        if d["ip"] and d["gw"]:
            line(d["ping"] != "no reply", "Gateway %s: %s" % (d["gw"], d["ping"]))
        s = otc.read_json(otc.SENSORJ)
        if not s.get("central"):
            line(None, "Central address not set - press 'Central server'")
        else:
            try:
                sys.path.insert(0, D)
                import otsense
                steps, _m = otsense.test_central(s.get("central", ""), s.get("token", ""), s.get("cafile") or None, bool(s.get("insecure")), s.get("site", ""), timeout=6)
                for label, ok, detail in steps:
                    line(ok, "%s: %s" % (label, detail))
            except Exception as e:
                dns, tcp = otc.quick_central(s["central"])
                line(False, "test could not run: %s" % e)
                line(None, "DNS: %s  %s" % (dns, tcp))
        return "\n".join(out)
    bg(work, "Test connectivity")


def a_ping():
    host = ask("Ping", "Host name or IP to ping", st.d.get("gw") or "8.8.8.8")
    if not host or not re.match(r"^[A-Za-z0-9._:-]+$", host):
        return
    bg(lambda: otc.sh(["ping", "-c", "4", "-W", "2", host], timeout=15)[1] or "no output", "Ping " + host)


def a_pw():
    if messagebox.askyesno("Web password", "Web page: %s\nPassword: %s\n\nSet a new password?" % (otc.web_url(st), st.d.get("pw") or "(not created yet)"), parent=root):
        pw = ask("New password", "New web password (at least 8 characters)")
        if pw and len(pw) >= 8:
            otc.write_private(otc.PWFILE, pw)
            otc.restart_sensor()
            messagebox.showinfo("Password", "Saved. The sensor is restarting.")
        elif pw:
            messagebox.showerror("Password", "Too short - use at least 8 characters.")


def a_restart():
    otc.restart_sensor()
    messagebox.showinfo("Sensor", "The sensor service is restarting (about 20 seconds).")


def a_log():
    bg(lambda: otc.sh(["journalctl", "-u", otc.SERVICE, "-n", "80", "--no-pager", "-o", "cat"], timeout=10)[1] or "no log yet", "Sensor log")


def a_text():
    if messagebox.askyesno("Text screen", "Switch to the text screen? (it also works without graphics)"):
        root.destroy()
        sys.exit(3)


def a_reboot():
    if messagebox.askyesno("Restart", "Restart this sensor now?"):
        otc.sh(["systemctl", "reboot"])


def a_off():
    if messagebox.askyesno("Power off", "Power off this sensor now?"):
        otc.sh(["systemctl", "poweroff"])


def a_web():
    open_web(ent_url.get() or otc.web_url(st))


BUTTONS = [("Network address", a_network), ("Ports (mgmt / SPAN)", a_ports), ("Remote access port (SRA)", a_sra), ("Central server", a_central), ("Test connectivity", a_test),
           ("Ping", a_ping), ("Web password", a_pw), ("Restart sensor", a_restart), ("Show log", a_log),
           ("Open web page", a_web), ("Text screen", a_text), ("Restart", a_reboot), ("Power off", a_off)]
fr = tk.Frame(root, bg=BG)
fr.pack(fill="x", padx=14, pady=8)
for i, (name, fn) in enumerate(BUTTONS):
    b = tk.Button(fr, text=name, command=fn, font=FB, bg="#2d4a66", fg="white", activebackground="#3f6a94", activeforeground="white", relief="raised", bd=3, height=1, pady=6)
    b.grid(row=i // 4, column=i % 4, sticky="nsew", padx=4, pady=4)
    b.bind("<Return>", lambda e: e.widget.invoke())
for c in range(4):
    fr.columnconfigure(c, weight=1)
refresh()
root.mainloop()
