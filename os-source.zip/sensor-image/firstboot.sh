#!/usr/bin/env bash
# OT Sense sensor, Raspberry Pi / Ubuntu image - applies /etc/otsense/sensor.conf: network (Wi-Fi or cable), name, time server, sensor container.
# Runs once from cloud-init (the seed central generated) and again, with FORCE=1, whenever the console screen changes something.
#   NETONLY=1  only the network part (used by the console screen for quick changes)
# Test without changing anything:  DRY_RUN=1 NICS="eth0 eth1" WIFI=wlan0 CONF=./sensor.conf ./firstboot.sh
set -uo pipefail
DRY="${DRY_RUN:-0}"; CONF="${CONF:-/etc/otsense/sensor.conf}"; FORCE="${FORCE:-0}"; NETONLY="${NETONLY:-0}"
[ "$DRY" = 1 ] || { exec >>/var/log/otsense-firstboot.log 2>&1; [ -f /var/lib/otsense-firstboot.done ] && [ "$FORCE" != 1 ] && exit 0; }
run() { if [ "$DRY" = 1 ]; then echo "+ $*"; else "$@"; fi; }
echo "=== OT Sense apply $(date -u +%FT%TZ)"
# shellcheck disable=SC1090
. "$CONF" || { echo "no sensor.conf - seed missing"; exit 1; }
MGMT_MODE="${MGMT_MODE:-dhcp}"; IP_CIDR="${IP_CIDR:-}"; GATEWAY="${GATEWAY:-}"; DNS="${DNS:-}"; SCAN="${SCAN:-passive}"
WIFI_SSID="${WIFI_SSID:-}"; WIFI_PSK="${WIFI_PSK:-}"; WIFI_COUNTRY="${WIFI_COUNTRY:-}"; MGMT_PORT="${MGMT_PORT:-}"; NTP="${NTP:-}"; HOSTNAME_FQDN="${HOSTNAME_FQDN:-}"

# 1. ports. Wi-Fi card + SSID given -> the Wi-Fi card is the MANAGEMENT port (internet, central, web page) and every wired port is a SPAN/capture port.
#    No Wi-Fi given -> first wired port = management, all other wired ports = capture. MGMT_PORT (chosen on the console screen) wins.
WIRED=""; WIFIIF=""
if [ -n "${NICS:-}" ]; then WIRED="$NICS"; WIFIIF="${WIFI:-}"; else
  for d in /sys/class/net/*; do n="$(basename "$d")"
    case "$n" in lo|docker*|veth*|br-*|virbr*|tun*|tap*|ifb*|bond*) continue;; esac
    [ -e "$d/device" ] || continue
    if [ -d "$d/wireless" ] || [ -d "$d/phy80211" ]; then WIFIIF="$n"; else WIRED="$WIRED $n"; fi
  done; WIRED="$(echo "$WIRED" | tr ' ' '\n' | sed '/^$/d' | sort | tr '\n' ' ')"; fi
MGMT=""
if [ -n "$MGMT_PORT" ] && { [ "$MGMT_PORT" = "$WIFIIF" ] || echo " $WIRED " | grep -q " $MGMT_PORT "; }; then MGMT="$MGMT_PORT"
elif [ -n "$WIFIIF" ] && [ -n "$WIFI_SSID" ]; then MGMT="$WIFIIF"
else set -- $WIRED; MGMT="${1:-}"; fi
CAP=""; for n in $WIRED; do [ "$n" = "$MGMT" ] || CAP="${CAP:+$CAP,}$n"; done
echo "ports: management=${MGMT:-none} capture=${CAP:-none} wifi=${WIFIIF:-none}"
[ -n "$MGMT" ] || { echo "no network port found"; exit 1; }
NETYAML="$(mktemp)"
MGMT="$MGMT" CAP="$CAP" WIFIIF="$WIFIIF" MGMT_MODE="$MGMT_MODE" IP_CIDR="$IP_CIDR" GATEWAY="$GATEWAY" DNS="$DNS" WIFI_SSID="$WIFI_SSID" WIFI_PSK="$WIFI_PSK" WIFI_COUNTRY="$WIFI_COUNTRY" \
python3 - > "$NETYAML" <<'PY'
import json, os, re
e = os.environ
def mgmt_block():
    b = {}
    if e["MGMT_MODE"] == "static":
        b["dhcp4"] = False; b["addresses"] = [e["IP_CIDR"]]
        if e["GATEWAY"]: b["routes"] = [{"to": "default", "via": e["GATEWAY"]}]
        d = [x for x in re.split(r"[ ,]+", e["DNS"]) if x]
        if d: b["nameservers"] = {"addresses": d}
    else:
        b["dhcp4"] = True
    return b
eth, wifis = {}, {}
if e["MGMT"] == e["WIFIIF"] and e["WIFIIF"]:
    w = mgmt_block(); w["access-points"] = {e["WIFI_SSID"]: ({"password": e["WIFI_PSK"]} if e["WIFI_PSK"] else {})}
    if e["WIFI_COUNTRY"]: w["regulatory-domain"] = e["WIFI_COUNTRY"].upper()
    w["optional"] = True; wifis[e["MGMT"]] = w
else:
    eth[e["MGMT"]] = mgmt_block()
for n in [x for x in e["CAP"].split(",") if x]:
    eth[n] = {"dhcp4": False, "dhcp6": False, "accept-ra": False, "link-local": []}
net = {"network": {"version": 2, "renderer": "networkd"}}
if eth: net["network"]["ethernets"] = eth
if wifis: net["network"]["wifis"] = wifis
print(json.dumps(net, indent=1))
PY
if [ "$DRY" = 1 ]; then cat "$NETYAML"; else
  rm -f /etc/netplan/50-cloud-init.yaml; install -m 600 "$NETYAML" /etc/netplan/60-otsense.yaml
  [ -n "$CAP" ] && for n in ${CAP//,/ }; do ip link set "$n" up promisc on 2>/dev/null; done
  netplan apply; sleep 5; fi
rm -f "$NETYAML"

# 2. name of this sensor and time server of the site
if [ -n "$HOSTNAME_FQDN" ]; then run hostnamectl set-hostname "${HOSTNAME_FQDN%%.*}"; [ "$DRY" = 1 ] || { grep -q "$HOSTNAME_FQDN" /etc/hosts || echo "127.0.1.1 $HOSTNAME_FQDN ${HOSTNAME_FQDN%%.*}" >> /etc/hosts; }; fi
if [ -n "$NTP" ]; then
  if [ "$DRY" = 1 ]; then echo "+ NTP=$NTP"; else mkdir -p /etc/systemd/timesyncd.conf.d; printf '[Time]\nNTP=%s\n' "${NTP//,/ }" > /etc/systemd/timesyncd.conf.d/otsense.conf; systemctl restart systemd-timesyncd 2>/dev/null || true; fi
fi
[ "$NETONLY" = 1 ] && { echo "=== network applied"; exit 0; }

# 3. CA of central (own CA if the seed carried one, otherwise the normal public CA list)
run mkdir -p /opt/otsense-sensor
if [ -s /etc/otsense/ca.crt ]; then run cp /etc/otsense/ca.crt /opt/otsense-sensor/ca.crt
else run cp /etc/ssl/certs/ca-certificates.crt /opt/otsense-sensor/ca.crt; fi

# 4. container engine + sensor image (the Raspberry Pi installs them here: needs internet once - with Wi-Fi management it comes over the Wi-Fi)
if ! command -v docker >/dev/null || [ "$DRY" = 1 ]; then
  [ "$DRY" = 1 ] || for i in $(seq 1 40); do ping -c1 -W2 1.1.1.1 >/dev/null 2>&1 && break; sleep 3; done
  command -v docker >/dev/null || { run apt-get update -qq; run apt-get install -y -qq docker.io; run systemctl enable --now docker; }
fi
if [ -z "$(docker images -q otsense:1.3 2>/dev/null)" ] || [ "$DRY" = 1 ]; then
  if [ -f /opt/otsense/otsense-image.tar.gz ]; then run docker load -i /opt/otsense/otsense-image.tar.gz
  else run docker build -q -t otsense:1.3 /opt/otsense/src; fi
fi

# 5. start the sensor (joins central by itself, token comes from the seed)
run docker rm -f otsense-sensor
run docker run -d --name otsense-sensor --restart unless-stopped --network host --cap-add NET_RAW --cap-add NET_ADMIN \
  -v otsense-sensor:/data -v /opt/otsense-sensor:/pack:ro \
  -e OTSENSE_SITE="${SITE:-}" -e OTSENSE_CENTRAL="${CENTRAL:-}" -e OTSENSE_TOKEN="${TOKEN:-}" -e OTSENSE_IFACE="$CAP" -e OTSENSE_MGMT="$MGMT" -e OTSENSE_SCAN="$SCAN" otsense:1.3 sensor
[ "$DRY" = 1 ] || { touch /var/lib/otsense-firstboot.done; systemctl restart otsense-banner 2>/dev/null || true; }
echo "=== done"
