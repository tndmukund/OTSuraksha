#!/usr/bin/env bash
# Raspberry Pi (ARM) image only - the x86 ISO is built by build-iso.sh.   sudo ./build-rpi-image.sh /path/to/otsense-docker   -> ./images/otsense-sensor-rpi.img.xz
# NOTE: not tested on a real Pi yet. Wi-Fi management (Wi-Fi name/password come from central's seed) + console screen on HDMI (tty1).
set -euo pipefail
SRC="${1:-}"; [ -f "$SRC/Dockerfile" ] || { echo "usage: sudo $0 /path/to/otsense-docker"; exit 1; }
SRC="$(readlink -f "$SRC")"; HERE="$(cd "$(dirname "$0")" && pwd)"; OUT="${OUT_DIR:-$HERE/images}"; W="$HERE/work"
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }
mkdir -p "$OUT" "$W"; cd "$W"; apt-get update -qq; apt-get install -y -qq libguestfs-tools xz-utils curl ca-certificates; export LIBGUESTFS_BACKEND=direct
echo "[1/1] Raspberry Pi 64-bit (Ubuntu 24.04 preinstalled server image)"
RPI_URL="${RPI_URL:-}"
if [ -z "$RPI_URL" ]; then
  RPI_URL="https://cdimage.ubuntu.com/releases/24.04/release/$(curl -fsSL https://cdimage.ubuntu.com/releases/24.04/release/ | grep -o 'ubuntu-24\.04[0-9.]*-preinstalled-server-arm64+raspi\.img\.xz' | sort -u | tail -1)"
fi
[ -f rpi.img.xz ] || curl -fL -o rpi.img.xz "$RPI_URL"
xz -dc rpi.img.xz > rpi.img
# no chroot needed: the Pi installs Docker and builds the container itself on first boot (needs internet once)
# Nothing is executed inside the ARM image (this build machine is x86): files are copied, links and permissions are set by libguestfs itself.
virt-customize -a rpi.img --mkdir /opt/otsense/src \
  --copy-in "$HERE/firstboot.sh:/opt/otsense" --copy-in "$HERE/otsense-banner.sh:/opt/otsense" \
  --copy-in "$HERE/iso/otsense-console.py:/opt/otsense" --copy-in "$HERE/iso/otsense-pi-console.py:/opt/otsense" \
  --copy-in "$HERE/otsense-banner.service:/etc/systemd/system" --copy-in "$HERE/iso/otsense-pi-console.service:/etc/systemd/system" \
  --copy-in "$SRC/Dockerfile:/opt/otsense/src" --copy-in "$SRC/otsense.py:/opt/otsense/src" --copy-in "$SRC/otsense_central.py:/opt/otsense/src" \
  --copy-in "$SRC/entrypoint.sh:/opt/otsense/src" --copy-in "$SRC/README.md:/opt/otsense/src" \
  --copy-in "$SRC/sample_ot.pcap:/opt/otsense/src" --copy-in "$SRC/sample_clean.pcap:/opt/otsense/src" \
  --chmod 0755:/opt/otsense/firstboot.sh --chmod 0755:/opt/otsense/otsense-banner.sh --chmod 0755:/opt/otsense/otsense-console.py --chmod 0755:/opt/otsense/otsense-pi-console.py \
  --link /etc/systemd/system/otsense-banner.service:/etc/systemd/system/multi-user.target.wants/otsense-banner.service \
  --link /etc/systemd/system/otsense-pi-console.service:/etc/systemd/system/multi-user.target.wants/otsense-pi-console.service \
  --link /dev/null:/etc/systemd/system/getty@tty1.service
xz -T0 -f -c rpi.img > "$OUT/otsense-sensor-rpi.img.xz"; rm -f rpi.img

ls -lh "$OUT"
echo "Keep these files next to your central; they contain no passwords or tokens and can be reused for every site."
