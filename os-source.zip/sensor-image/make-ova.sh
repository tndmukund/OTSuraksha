#!/usr/bin/env bash
# Turns the finished sensor ISO into an OVA (a ready-made VM: import it, power on, done).
#   usage: ./make-ova.sh otsense-sensor.iso otsense-sensor.ova
# The OVA has 2 vCPU, 4 GB RAM, 4 network ports (1 management + 3 SPAN/capture) and 2 disks:
#   disk 1 = the sensor system (the ISO written to a disk; bootable, hybrid image)
#   disk 2 = 16 GB (thin) "OTDATA" disk that keeps the sensor's settings, so nothing has to be typed again after a reboot.
# Virtual network cards are plain E1000 (1 Gbit/s, works in VMware, VirtualBox and Proxmox); the ports of a real server
# (copper, fiber, SFP, 10G and above) are handled by the Linux drivers of the same system when it runs on real hardware.
set -euo pipefail
ISO="${1:?usage: make-ova.sh in.iso out.ova [out.img]}"; OVA="$(readlink -m "${2:?usage: make-ova.sh in.iso out.ova [out.img]}")"; IMG="${3:-}"
[ -s "$ISO" ] || { echo "ISO not found: $ISO"; exit 1; }
need() { command -v "$1" >/dev/null 2>&1; }
if ! need qemu-img || ! need mkfs.ext4 || ! need xorriso; then
  [ "$(id -u)" -eq 0 ] || SUDO=sudo; ${SUDO:-} apt-get update -qq; ${SUDO:-} apt-get install -y -qq qemu-utils e2fsprogs xorriso
fi
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
NAME="OTSense-Sensor"; DATA_GB=16
SZ="$(stat -c %s "$ISO")"; MB=$(( (SZ + 1048575) / 1048576 + 2 )); SYS_BYTES=$(( MB * 1048576 )); DATA_BYTES=$(( DATA_GB * 1073741824 ))
echo "[ova] system disk: ${MB} MB, settings disk: ${DATA_GB} GB (thin)"
truncate -s "${MB}M" "$W/system.raw"; dd if="$ISO" of="$W/system.raw" conv=notrunc status=none
truncate -s "${DATA_GB}G" "$W/data.raw"; mkfs.ext4 -q -F -L OTDATA -m 0 "$W/data.raw"
qemu-img convert -f raw -O vmdk -o subformat=streamOptimized "$W/system.raw" "$W/disk1.vmdk"
qemu-img convert -f raw -O vmdk -o subformat=streamOptimized "$W/data.raw" "$W/disk2.vmdk"
# the same system disk as a plain raw image: central stamps it in place (Hyper-V / VirtualBox .vhd = this + a footer, Proxmox / KVM / Xen use it as is)
if [ -n "$IMG" ]; then cp "$W/system.raw" "$IMG"; fi
rm -f "$W/system.raw" "$W/data.raw"
# config CD (label OTCONFIG): holds ONE empty 64 KB "slot". Central swaps this site's settings (site name, central URL, token, IP, DNS, NTP...) into it
# while the OVA is downloaded, exactly like it does for the ISO. The sensor reads it at every boot.
mkdir -p "$W/cfg/otsense"
python3 -c "import sys; sys.stdout.buffer.write(b'OTSENSE_SLOT_V1\n' + bytes(65536-16))" > "$W/cfg/otsense/slot.bin"
xorriso -as mkisofs -quiet -V OTCONFIG -r -J -o "$W/config.iso" "$W/cfg" >/dev/null 2>&1
S1="$(stat -c %s "$W/disk1.vmdk")"; S2="$(stat -c %s "$W/disk2.vmdk")"; S3="$(stat -c %s "$W/config.iso")"
python3 - "$W" "$NAME" "$SYS_BYTES" "$DATA_BYTES" "$S1" "$S2" "$S3" <<'PY'
import sys
w, name, sysb, datab, s1, s2, s3 = sys.argv[1:8]
nets = [("Management", "Management port (first network card: web page, central link)"),
        ("SPAN 1", "Capture port 1 (mirrored traffic, no IP address)"),
        ("SPAN 2", "Capture port 2 (mirrored traffic, no IP address)"),
        ("SPAN 3", "Capture port 3 (mirrored traffic, no IP address)")]
net_xml = "".join('    <Network ovf:name="%s"><Description>%s</Description></Network>\n' % (n, d) for n, d in nets)
nic_xml = ""
for i, (n, d) in enumerate(nets):
    nic_xml += f'''      <Item>
        <rasd:AddressOnParent>{7 + i}</rasd:AddressOnParent>
        <rasd:AutomaticAllocation>true</rasd:AutomaticAllocation>
        <rasd:Connection>{n}</rasd:Connection>
        <rasd:Description>E1000 ethernet adapter on "{n}"</rasd:Description>
        <rasd:ElementName>Ethernet {i + 1}</rasd:ElementName>
        <rasd:InstanceID>{6 + i}</rasd:InstanceID>
        <rasd:ResourceSubType>E1000</rasd:ResourceSubType>
        <rasd:ResourceType>10</rasd:ResourceType>
      </Item>
'''
ovf = f'''<?xml version="1.0" encoding="UTF-8"?>
<Envelope xmlns="http://schemas.dmtf.org/ovf/envelope/1" xmlns:cim="http://schemas.dmtf.org/wbem/wscim/1/common" xmlns:ovf="http://schemas.dmtf.org/ovf/envelope/1" xmlns:rasd="http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_ResourceAllocationSettingData" xmlns:vmw="http://www.vmware.com/schema/ovf" xmlns:vssd="http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_VirtualSystemSettingData" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <References>
    <File ovf:href="disk1.vmdk" ovf:id="file1" ovf:size="{s1}"/>
    <File ovf:href="disk2.vmdk" ovf:id="file2" ovf:size="{s2}"/>
    <File ovf:href="config.iso" ovf:id="file3" ovf:size="{s3}"/>
  </References>
  <DiskSection>
    <Info>Virtual disk information</Info>
    <Disk ovf:capacity="{sysb}" ovf:capacityAllocationUnits="byte" ovf:diskId="vmdisk1" ovf:fileRef="file1" ovf:format="http://www.vmware.com/interfaces/specifications/vmdk.html#streamOptimized"/>
    <Disk ovf:capacity="{datab}" ovf:capacityAllocationUnits="byte" ovf:diskId="vmdisk2" ovf:fileRef="file2" ovf:format="http://www.vmware.com/interfaces/specifications/vmdk.html#streamOptimized"/>
  </DiskSection>
  <NetworkSection>
    <Info>The list of logical networks</Info>
{net_xml}  </NetworkSection>
  <VirtualSystem ovf:id="{name}">
    <Info>OT Sense sensor</Info>
    <Name>{name}</Name>
    <OperatingSystemSection ovf:id="96" vmw:osType="debian11_64Guest">
      <Info>The kind of installed guest operating system</Info>
      <Description>Debian GNU/Linux (64-bit)</Description>
    </OperatingSystemSection>
    <VirtualHardwareSection>
      <Info>Virtual hardware requirements</Info>
      <System>
        <vssd:ElementName>Virtual Hardware Family</vssd:ElementName>
        <vssd:InstanceID>0</vssd:InstanceID>
        <vssd:VirtualSystemIdentifier>{name}</vssd:VirtualSystemIdentifier>
        <vssd:VirtualSystemType>vmx-13</vssd:VirtualSystemType>
      </System>
      <Item>
        <rasd:AllocationUnits>hertz * 10^6</rasd:AllocationUnits>
        <rasd:Description>Number of Virtual CPUs</rasd:Description>
        <rasd:ElementName>2 virtual CPU(s)</rasd:ElementName>
        <rasd:InstanceID>1</rasd:InstanceID>
        <rasd:ResourceType>3</rasd:ResourceType>
        <rasd:VirtualQuantity>2</rasd:VirtualQuantity>
      </Item>
      <Item>
        <rasd:AllocationUnits>byte * 2^20</rasd:AllocationUnits>
        <rasd:Description>Memory Size</rasd:Description>
        <rasd:ElementName>4096MB of memory</rasd:ElementName>
        <rasd:InstanceID>2</rasd:InstanceID>
        <rasd:ResourceType>4</rasd:ResourceType>
        <rasd:VirtualQuantity>4096</rasd:VirtualQuantity>
      </Item>
      <Item>
        <rasd:Address>0</rasd:Address>
        <rasd:Description>SATA Controller</rasd:Description>
        <rasd:ElementName>SATA controller 0</rasd:ElementName>
        <rasd:InstanceID>3</rasd:InstanceID>
        <rasd:ResourceSubType>AHCI</rasd:ResourceSubType>
        <rasd:ResourceType>20</rasd:ResourceType>
      </Item>
      <Item>
        <rasd:AddressOnParent>0</rasd:AddressOnParent>
        <rasd:ElementName>Hard Disk 1 (system)</rasd:ElementName>
        <rasd:HostResource>ovf:/disk/vmdisk1</rasd:HostResource>
        <rasd:InstanceID>4</rasd:InstanceID>
        <rasd:Parent>3</rasd:Parent>
        <rasd:ResourceType>17</rasd:ResourceType>
      </Item>
      <Item>
        <rasd:AddressOnParent>1</rasd:AddressOnParent>
        <rasd:ElementName>Hard Disk 2 (settings)</rasd:ElementName>
        <rasd:HostResource>ovf:/disk/vmdisk2</rasd:HostResource>
        <rasd:InstanceID>5</rasd:InstanceID>
        <rasd:Parent>3</rasd:Parent>
        <rasd:ResourceType>17</rasd:ResourceType>
      </Item>
      <Item>
        <rasd:AddressOnParent>2</rasd:AddressOnParent>
        <rasd:AutomaticAllocation>true</rasd:AutomaticAllocation>
        <rasd:ElementName>CD/DVD Drive 1 (settings from central)</rasd:ElementName>
        <rasd:HostResource>ovf:/file/file3</rasd:HostResource>
        <rasd:InstanceID>11</rasd:InstanceID>
        <rasd:Parent>3</rasd:Parent>
        <rasd:ResourceType>15</rasd:ResourceType>
      </Item>
{nic_xml}    </VirtualHardwareSection>
  </VirtualSystem>
</Envelope>
'''
open(w + "/" + name + ".ovf", "w").write(ovf)
PY
rm -f "$OVA"; tar --format=ustar -C "$W" -cf "$OVA" "$NAME.ovf" disk1.vmdk disk2.vmdk config.iso
# central finds the slot by its marker: there must be exactly ONE in the whole OVA
N="$(python3 - "$OVA" <<'PY'
import sys
M=b"OTSENSE_SLOT_V1\n"; n=0; tail=b""
with open(sys.argv[1],"rb") as f:
    while True:
        c=f.read(8<<20)
        if not c: break
        b=tail+c; n+=b.count(M); tail=b[-15:]
print(n)
PY
)"
[ "$N" = 1 ] || { echo "ERROR: OVA has $N config slots (expected 1)"; exit 1; }
if [ -n "$IMG" ]; then N2="$(python3 -c "import sys;d=open(sys.argv[1],'rb').read();print(d.count(b'OTSENSE_SLOT_V1\\n'))" "$IMG")"; [ "$N2" = 1 ] || { echo "ERROR: raw image has $N2 config slots (expected 1)"; exit 1; }; ls -lh "$IMG"; fi
tar -tf "$OVA"; ls -lh "$OVA"
